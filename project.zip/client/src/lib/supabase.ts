import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    // Configure auth settings for better session management
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    // Set custom storage for session persistence
    storage: {
      getItem: (key: string) => {
        if (typeof window !== 'undefined') {
          return window.localStorage.getItem(key)
        }
        return null
      },
      setItem: (key: string, value: string) => {
        if (typeof window !== 'undefined') {
          window.localStorage.setItem(key, value)
        }
      },
      removeItem: (key: string) => {
        if (typeof window !== 'undefined') {
          window.localStorage.removeItem(key)
        }
      },
    },
  },
})

export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          username: string
          email: string
          name: string
          bio: string
          avatar: string
          banner: string
          background_image: string
          page_url: string
          is_public: boolean
          view_count: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          username: string
          email: string
          name: string
          bio?: string
          avatar?: string
          banner?: string
          background_image?: string
          page_url: string
          is_public?: boolean
          view_count?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          username?: string
          email?: string
          name?: string
          bio?: string
          avatar?: string
          banner?: string
          background_image?: string
          page_url?: string
          is_public?: boolean
          view_count?: number
          created_at?: string
          updated_at?: string
        }
      }
      bio_pages: {
        Row: {
          id: string
          user_id: string
          title: string
          description: string
          custom_settings: any
          social_links: any
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          description?: string
          custom_settings?: any
          social_links?: any
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          description?: string
          custom_settings?: any
          social_links?: any
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}