import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useAdmin } from "@/hooks/use-admin";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ProtectedRoute } from "@/components/protected-route";
import { InviteStatsCard } from "@/components/invites/invite-stats-card";
import { InviteList } from "@/components/invites/invite-list";
import { useToast } from "@/hooks/use-toast";
import { Shield, Gift, UserPlus, Clock, LogOut } from "lucide-react";

export default function Dashboard() {
  const { user, signOut, session } = useAuth();
  const { isAdmin } = useAdmin();
  const { toast } = useToast();

  const { data: userProfile, isLoading } = useQuery({
    queryKey: ["user-profile", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from("users")
        .select(`
          *,
          invited_by_user:invited_by(username, avatar, user_number)
        `)
        .eq("id", user.id)
        .maybeSingle();

      if (error) {
        console.error("Error fetching user profile:", error);
        throw error;
      }
      
      if (!data) return null;
      
      console.log("User profile data:", data); // Debug log
      return data;
    },
    enabled: !!user?.id,
  });

  const { data: bioPage } = useQuery({
    queryKey: ["bio-page", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from("bio_pages")
        .select("*")
        .eq("user_id", user.id)
        .eq("is_active", true)
        .maybeSingle();

      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: "Выход выполнен",
        description: "Вы успешно вышли из аккаунта. Сессия очищена.",
      });
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось выйти из аккаунта",
        variant: "destructive",
      });
    }
  };

  // Calculate session expiry info
  const getSessionInfo = () => {
    if (!session?.expires_at) return null;
    
    const expiresAt = new Date(session.expires_at * 1000);
    const now = new Date();
    const timeLeft = expiresAt.getTime() - now.getTime();
    
    if (timeLeft <= 0) return { expired: true };
    
    const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
    const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    return { expired: false, days, hours, expiresAt };
  };

  const sessionInfo = getSessionInfo();

  return (
    <ProtectedRoute>
      <div className="min-h-screen relative overflow-hidden bg-dark-gradient-subtle">
        {/* Background Elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-slate-600/8 rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-slate-500/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '-3s' }}></div>
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-slate-700/6 rounded-full blur-3xl animate-float" style={{ animationDelay: '-1.5s' }}></div>
        </div>

        {/* Navigation */}
        <nav className="relative z-50 glass-morphism border-b border-slate-400/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-slate-600 to-slate-500 rounded-lg flex items-center justify-center shadow-lg">
                  <i className="fas fa-user-circle text-white text-sm"></i>
                </div>
                <h1 className="text-xl font-bold text-white">Personal Curator</h1>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <span className="text-slate-200 block">
                    Привет, @{userProfile?.username || user?.email}!
                  </span>
                </div>
                
                {isAdmin && (
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-red-500/20 text-red-300 border border-red-500/30">
                    <Shield className="w-3 h-3 mr-1" />
                    Admin
                  </span>
                )}
                
                {isAdmin && (
                  <Link href="/admin">
                    <Button
                      variant="outline"
                      className="text-red-300 border-red-400/50 hover:bg-red-400/10 glass-light"
                    >
                      <Shield className="w-4 h-4 mr-2" />
                      Админ-панель
                    </Button>
                  </Link>
                )}
                
                <Button
                  onClick={handleSignOut}
                  variant="ghost"
                  className="text-slate-200 hover:text-white border-slate-400/20 glass-light"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Выйти
                </Button>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <div className="relative z-10 max-w-4xl mx-auto px-4 py-8">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="glass-morphism p-8 rounded-2xl">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-300 mx-auto"></div>
                <p className="text-white mt-4">Загрузка...</p>
              </div>
            </div>
          ) : (
            <div className="space-y-8">
              
              {/* Profile Overview */}
              <Card className="glass-dark border-slate-400/10 card-hover">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <i className="fas fa-user mr-3 text-slate-400"></i>
                    Обзор профиля
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-white font-medium mb-2">Основная информация</h3>
                      <div className="space-y-2 text-sm">
                        <p className="text-slate-200">
                          <span className="text-slate-400">Username:</span> @{userProfile?.username || 'не указан'}
                        </p>
                        <p className="text-slate-200">
                          <span className="text-slate-400">Email:</span> {userProfile?.email || user?.email || 'не указан'}
                        </p>
                        <p className="text-slate-200">
                          <span className="text-slate-400">URL:</span> curator.bio/{userProfile?.page_url || 'не указан'}
                        </p>
                        <p className="text-slate-200">
                          <span className="text-slate-400">User ID:</span> #{userProfile?.user_number || 'не назначен'}
                        </p>
                        
                        {/* Invited by section */}
                        {userProfile?.invited_by_user ? (
                          <div className="mt-3 p-3 glass-light border border-slate-500/20 rounded-lg">
                            <p className="text-slate-300 font-medium flex items-center text-sm">
                              <UserPlus className="w-4 h-4 mr-2" />
                              Приглашен пользователем
                            </p>
                            <div className="flex items-center mt-2 space-x-3">
                              <img
                                src={userProfile.invited_by_user.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=100&h=100&fit=crop&crop=face"}
                                alt={userProfile.invited_by_user.username}
                                className="w-8 h-8 rounded-full object-cover border-2 border-slate-400/30"
                              />
                              <div>
                                <p className="text-white font-medium">@{userProfile.invited_by_user.username}</p>
                                <p className="text-slate-400 text-xs">ID: #{userProfile.invited_by_user.user_number}</p>
                              </div>
                            </div>
                          </div>
                        ) : userProfile?.invited_by ? (
                          <div className="mt-3 p-3 glass-light border border-slate-500/20 rounded-lg">
                            <p className="text-slate-300 font-medium flex items-center text-sm">
                              <UserPlus className="w-4 h-4 mr-2" />
                              Приглашен пользователем
                            </p>
                            <p className="text-slate-400 text-xs mt-1">
                              ID: {userProfile.invited_by}
                            </p>
                          </div>
                        ) : (
                          <div className="mt-3 p-3 glass-light border border-slate-600/20 rounded-lg">
                            <p className="text-slate-300 font-medium flex items-center text-sm">
                              <Gift className="w-4 h-4 mr-2" />
                              Оригинальный пользователь
                            </p>
                            <p className="text-slate-400 text-xs mt-1">
                              Зарегистрировался без инвайт-кода
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-2">Статистика</h3>
                      <div className="space-y-2 text-sm">
                        <p className="text-slate-200">
                          <span className="text-slate-400">Просмотры:</span> {userProfile?.view_count || 0}
                        </p>
                        <p className="text-slate-200">
                          <span className="text-slate-400">Статус:</span> {userProfile?.is_public ? 'Публичный' : 'Приватный'}
                        </p>
                        <p className="text-slate-200">
                          <span className="text-slate-400">Био-страница:</span> {bioPage ? 'Создана' : 'Не создана'}
                        </p>
                        <p className="text-slate-200">
                          <span className="text-slate-400">Дата регистрации:</span> {userProfile?.created_at ? new Date(userProfile.created_at).toLocaleDateString('ru-RU') : 'не указана'}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="glass-dark border-slate-400/10 card-hover">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <i className="fas fa-bolt mr-3 text-yellow-400"></i>
                    Быстрые действия
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    <Button
                      onClick={() => window.location.href = '/editor'}
                      className="w-full btn-dark-gradient text-white shadow-lg"
                    >
                      <i className="fas fa-edit mr-2"></i>
                      {bioPage ? 'Редактировать страницу' : 'Создать био-страницу'}
                    </Button>
                    
                    {userProfile?.page_url && (
                      <Button
                        onClick={() => window.open(`/${userProfile.page_url}`, '_blank')}
                        variant="outline"
                        className="w-full border-slate-400/20 text-white hover:bg-slate-700/20 glass-light"
                      >
                        <i className="fas fa-external-link-alt mr-2"></i>
                        Посмотреть страницу
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Invite Stats */}
              <Card className="glass-dark border-slate-400/10 card-hover">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Gift className="w-5 h-5 mr-3 text-slate-400" />
                    Статистика инвайтов
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <InviteStatsCard />
                </CardContent>
              </Card>

              {/* Invite Management */}
              <InviteList />

              {/* Session Status Card - Moved to bottom */}
              {sessionInfo && (
                <Card className="glass-dark border-slate-400/10 card-hover">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Clock className="w-5 h-5 mr-3 text-green-400" />
                      Статус сессии
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {sessionInfo.expired ? (
                      <div className="text-red-400">
                        <p className="font-medium">Сессия истекла</p>
                        <p className="text-sm text-slate-400">Пожалуйста, войдите заново</p>
                      </div>
                    ) : (
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-green-400 font-medium">Активная сессия</p>
                          <p className="text-slate-300 text-sm">
                            Осталось: {sessionInfo.days} дней {sessionInfo.hours} часов
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-400 text-sm">
                            Истекает: {sessionInfo.expiresAt?.toLocaleDateString('ru-RU', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </p>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </div>
      </div>
    </ProtectedRoute>
  );
}