import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    rememberMe: true, // Default to true for better UX
  });
  const [loading, setLoading] = useState(false);
  const { signIn } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await signIn(formData.email, formData.password, formData.rememberMe);
      
      toast({
        title: "Добро пожаловать!",
        description: formData.rememberMe 
          ? "Вы успешно вошли в аккаунт. Сессия сохранена на 30 дней."
          : "Вы успешно вошли в аккаунт.",
      });

      setLocation("/dashboard");
    } catch (error: any) {
      toast({
        title: "Ошибка входа",
        description: error.message || "Неверный email или пароль",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-dark-gradient">
      {/* Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-slate-600/8 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-slate-500/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '-3s' }}></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-slate-700/6 rounded-full blur-3xl animate-float" style={{ animationDelay: '-1.5s' }}></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-50 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/">
            <div className="glass-morphism px-6 py-3 rounded-2xl cursor-pointer">
              <h1 className="text-2xl font-bold text-white">Personal Curator</h1>
            </div>
          </Link>
          <div className="flex gap-4">
            <Link href="/register">
              <Button variant="ghost" className="glass-light text-white hover:bg-slate-700/20 border-slate-400/20">
                Регистрация
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="relative z-10 flex items-center justify-center min-h-[calc(100vh-100px)] p-4">
        <Card className="w-full max-w-md glass-dark border-slate-400/10 card-hover">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-white">
              Вход в аккаунт
            </CardTitle>
            <p className="text-slate-300">
              Добро пожаловать обратно!
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="email" className="text-slate-200">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-slate-800/30 border-slate-400/20 text-white placeholder-slate-400"
                  placeholder="alex@example.com"
                  required
                />
              </div>

              <div>
                <Label htmlFor="password" className="text-slate-200">Пароль</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="bg-slate-800/30 border-slate-400/20 text-white placeholder-slate-400"
                  placeholder="Введите пароль"
                  required
                />
              </div>

              {/* Remember Me Checkbox */}
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="rememberMe"
                  checked={formData.rememberMe}
                  onCheckedChange={(checked) => setFormData({ ...formData, rememberMe: !!checked })}
                  className="data-[state=checked]:bg-indigo-600 data-[state=checked]:border-indigo-600"
                />
                <Label htmlFor="rememberMe" className="text-slate-200 text-sm cursor-pointer">
                  Запомнить меня на 30 дней
                </Label>
              </div>

              <Button 
                type="submit" 
                className="w-full py-6 text-lg btn-dark-gradient text-white border-0 shadow-lg"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Вход...
                  </>
                ) : (
                  <>
                    <i className="fas fa-sign-in-alt mr-2"></i>
                    Войти
                  </>
                )}
              </Button>
            </form>

            <div className="text-center mt-6">
              <p className="text-slate-400 text-sm">
                Нет аккаунта?{" "}
                <Link href="/register" className="text-slate-300 hover:text-white transition-colors">
                  Зарегистрироваться
                </Link>
              </p>
            </div>

            {/* Security Notice */}
            <div className="mt-4 p-3 glass-light rounded-lg border border-slate-500/20">
              <p className="text-slate-300 text-xs text-center">
                <i className="fas fa-shield-alt mr-1 text-green-400"></i>
                Ваши данные защищены и сохраняются локально в зашифрованном виде
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}