import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/lib/supabase";
import BioCard from "@/components/bio-card";
import DesignPanel from "@/components/design-panel";
import SocialLinksEditor from "@/components/social-links-editor";
import ProfileEditor from "@/components/profile-editor";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useBioSettings } from "@/hooks/use-bio-settings";
import { ProtectedRoute } from "@/components/protected-route";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import type { DesignSettings, SocialLink, User, BioPage } from "@shared/schema";

export default function Editor() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [socialLinks, setSocialLinks] = useState<SocialLink[]>([]);

  const { data: userProfile, isLoading: userLoading } = useQuery({
    queryKey: ["user-profile", user?.id],
    queryFn: async (): Promise<User | null> => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from("users")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();

      if (error) throw error;
      
      if (!data) return null;
      
      // Transform snake_case to camelCase
      return {
        ...data,
        backgroundImage: data.background_image,
        viewCount: data.view_count,
        pageUrl: data.page_url,
        isPublic: data.is_public,
        userNumber: data.user_number,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      } as User;
    },
    enabled: !!user?.id,
  });

  const { data: bioPage, isLoading: bioLoading } = useQuery({
    queryKey: ["bio-page", user?.id],
    queryFn: async (): Promise<BioPage | null> => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from("bio_pages")
        .select("*")
        .eq("user_id", user.id)
        .eq("is_active", true)
        .maybeSingle();

      if (error) throw error;
      
      if (!data) return null;
      
      console.log("Loaded bio page from database:", data);
      
      // Transform snake_case to camelCase
      return {
        ...data,
        userId: data.user_id,
        customSettings: data.custom_settings,
        socialLinks: data.social_links,
        isActive: data.is_active,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      } as BioPage;
    },
    enabled: !!user?.id,
  });

  // Инициализируем настройки с данными из bioPage
  const { settings, updateSettings, isInitialized } = useBioSettings(
    bioPage?.customSettings as DesignSettings
  );

  // Load existing social links when bioPage loads
  useEffect(() => {
    if (bioPage?.socialLinks && Array.isArray(bioPage.socialLinks)) {
      console.log("Loading social links:", bioPage.socialLinks);
      setSocialLinks(bioPage.socialLinks as SocialLink[]);
    } else {
      // Сбрасываем социальные ссылки если нет данных
      setSocialLinks([]);
    }
  }, [bioPage?.socialLinks]);

  const saveSettingsMutation = useMutation({
    mutationFn: async (data: { settings: DesignSettings; socialLinks: SocialLink[] }) => {
      if (!user?.id) throw new Error("User not authenticated");

      console.log("Saving to Supabase:", { settings: data.settings, socialLinks: data.socialLinks });

      if (bioPage) {
        // Update existing bio page
        const { error } = await supabase
          .from("bio_pages")
          .update({
            custom_settings: data.settings,
            social_links: data.socialLinks,
            updated_at: new Date().toISOString(),
          })
          .eq("id", bioPage.id);

        if (error) {
          console.error("Supabase update error:", error);
          throw error;
        }
      } else {
        // Create new bio page
        const { error } = await supabase
          .from("bio_pages")
          .insert({
            user_id: user.id,
            title: userProfile?.username || "My Bio Page",
            description: userProfile?.bio || "",
            custom_settings: data.settings,
            social_links: data.socialLinks,
          });

        if (error) {
          console.error("Supabase insert error:", error);
          throw error;
        }
      }
    },
    onSuccess: () => {
      toast({
        title: "Сохранено!",
        description: "Настройки дизайна обновлены",
      });
      queryClient.invalidateQueries({ queryKey: ["bio-page", user?.id] });
    },
    onError: (error: any) => {
      console.error("Save error:", error);
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось сохранить настройки",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    console.log("Saving settings:", settings);
    console.log("Saving social links:", socialLinks);
    saveSettingsMutation.mutate({ settings, socialLinks });
  };

  const isLoading = userLoading || bioLoading;

  return (
    <ProtectedRoute>
      <div className="min-h-screen relative overflow-hidden bg-dark-gradient-alt">
        {/* Background Container with user's background image and blur */}
        <div className="fixed inset-0">
          {/* Background Image Layer with Blur */}
          <div 
            className="absolute inset-0"
            style={{
              backgroundImage: `url(${userProfile?.backgroundImage || "https://images.unsplash.com/photo-1557683316-973673baf926?ixlib=rb-4.0.3&w=1200&h=800&fit=crop"})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat',
              filter: settings?.backgroundBlur ? `blur(${settings.backgroundBlur}px)` : 'blur(5px)',
            }}
          ></div>
          
          {/* Background Color Overlay */}
          <div 
            className="absolute inset-0"
            style={{
              backgroundColor: settings?.backgroundColor 
                ? `rgba(${settings.backgroundColor.replace('#', '').match(/.{2}/g)?.map(hex => parseInt(hex, 16)).join(', ')}, ${(settings.backgroundOpacity || 100) / 100})`
                : 'rgba(15, 23, 42, 0.8)',
            }}
          ></div>
        </div>

        {/* Navigation */}
        <nav className="relative z-50 glass-morphism border-b border-slate-400/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-slate-600 to-slate-500 rounded-lg flex items-center justify-center shadow-lg">
                  <i className="fas fa-user-circle text-white text-sm"></i>
                </div>
                <h1 className="text-xl font-bold text-white">Personal Curator</h1>
              </div>
              
              <div className="flex items-center space-x-4">
                <Link href="/dashboard">
                  <Button
                    variant="ghost"
                    className="text-slate-200 hover:text-white border-slate-400/20 glass-light"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Назад
                  </Button>
                </Link>
                <Button
                  onClick={() => userProfile?.pageUrl && window.open(`/${userProfile.pageUrl}`, '_blank')}
                  variant="ghost"
                  className="text-slate-200 hover:text-white border-slate-400/20 glass-light"
                  disabled={!userProfile?.pageUrl}
                >
                  Предпросмотр
                </Button>
                <Button
                  onClick={handleSave}
                  disabled={saveSettingsMutation.isPending}
                  className="btn-dark-gradient text-white shadow-lg"
                >
                  {saveSettingsMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Сохранение...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-save mr-2"></i>
                      Сохранить
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </nav>

        {isLoading ? (
          <div className="relative z-10 min-h-screen flex items-center justify-center">
            <div className="glass-morphism p-8 rounded-2xl">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-300 mx-auto"></div>
              <p className="text-white mt-4">Загрузка редактора...</p>
            </div>
          </div>
        ) : (
          <div className="relative z-10 min-h-screen">
            <div className="max-w-7xl mx-auto px-4 py-8">
              <div className="grid lg:grid-cols-12 gap-8">
                
                {/* Left Panel - Design Controls */}
                <div className="lg:col-span-4 space-y-6">
                  <DesignPanel 
                    settings={settings}
                    onSettingsChange={updateSettings}
                  />
                </div>

                {/* Center - Bio Page Preview */}
                <div className="lg:col-span-5">
                  <div className="sticky top-24">
                    <div className="text-center mb-6">
                      <h2 className="text-2xl font-bold text-white mb-2">Предварительный просмотр</h2>
                      <p className="text-slate-300">Изменения применяются в реальном времени</p>
                      {!isInitialized && (
                        <p className="text-yellow-400 text-sm mt-2">Загрузка настроек...</p>
                      )}
                    </div>
                    
                    <div className="flex justify-center">
                      <BioCard 
                        user={userProfile}
                        bioPage={bioPage}
                        customSettings={settings}
                        customSocialLinks={socialLinks}
                        isPreview={true}
                      />
                    </div>
                  </div>
                </div>

                {/* Right Panel - Content Editor */}
                <div className="lg:col-span-3 space-y-6">
                  <SocialLinksEditor 
                    socialLinks={socialLinks}
                    onSocialLinksChange={setSocialLinks}
                  />
                  
                  <ProfileEditor 
                    user={userProfile}
                    onUserUpdate={() => {
                      queryClient.invalidateQueries({ queryKey: ["user-profile", user?.id] });
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}