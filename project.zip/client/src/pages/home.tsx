import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";

export default function Home() {
  const { user, loading } = useAuth();

  // Get user profile for authenticated users
  const { data: userProfile } = useQuery({
    queryKey: ["user-profile", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from("users")
        .select("username, avatar")
        .eq("id", user.id)
        .maybeSingle();

      if (error) return null;
      return data;
    },
    enabled: !!user?.id,
  });

  return (
    <div className="min-h-screen relative overflow-hidden bg-dark-gradient">
      {/* Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-slate-600/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-slate-500/15 rounded-full blur-3xl animate-float" style={{ animationDelay: '-3s' }}></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-slate-700/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '-1.5s' }}></div>
        <div className="absolute top-3/4 left-1/3 w-72 h-72 bg-slate-400/8 rounded-full blur-3xl animate-float" style={{ animationDelay: '-4s' }}></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-50 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="glass-morphism px-6 py-3 rounded-2xl">
            <h1 className="text-2xl font-bold text-white">Personal Curator</h1>
          </div>
          
          {/* Show different navigation based on auth status */}
          {loading ? (
            <div className="flex gap-4">
              <div className="w-20 h-10 bg-slate-600/20 rounded-lg animate-pulse"></div>
              <div className="w-24 h-10 bg-slate-600/20 rounded-lg animate-pulse"></div>
            </div>
          ) : user ? (
            /* Authenticated user navigation */
              <div className="flex items-center space-x-3 glass-light px-4 py-2 rounded-xl hover:bg-slate-700/30 transition-all cursor-pointer">
                <img
                  src={userProfile?.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=100&h=100&fit=crop&crop=face"}
                  alt={userProfile?.username || "User"}
                  className="w-8 h-8 rounded-full object-cover border-2 border-slate-400/30"
                />
                <div className="text-right" onClick={() => window.location.href = '/dashboard'}	>
                  <p className="text-white font-medium text-sm">
                    @{userProfile?.username || user.email?.split('@')[0]}
                  </p>
                  <p className="text-slate-400 text-xs">Панель управления</p>
                </div>
              </div>

          ) : (
            /* Guest navigation */
            <div className="flex gap-4">
              <Link href="/login">
                <Button variant="ghost" className="glass-light text-white hover:bg-slate-700/30 border-slate-400/20">
                  Войти
                </Button>
              </Link>
              <Link href="/register">
                <Button className="btn-dark-gradient text-white border-0 shadow-lg">
                  Регистрация
                </Button>
              </Link>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 py-16">
        <div className="text-center">
          <h1 className="text-5xl lg:text-7xl font-bold text-white mb-8 leading-tight">
            Создайте свою <br />
            <span className="bg-gradient-to-r from-slate-300 to-slate-100 bg-clip-text text-transparent">
              био-страницу
            </span>
          </h1>
          <p className="text-xl text-slate-300 mb-12 max-w-2xl mx-auto">
            Современный дизайн с glassmorphism эффектами. Полная кастомизация внешнего вида. 
            Создайте уникальную страницу для всех ваших ссылок.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            {user ? (
              /* Authenticated user actions */
              <>
                  <Button
                    onClick={() => window.location.href = '/dashboard'}				  
                    size="lg"
                    className="px-8 py-6 text-lg btn-dark-gradient text-white border-0 shadow-xl"
                  >
                    <i className="fas fa-tachometer-alt mr-2"></i>
                    Перейти в панель
                  </Button>
                  <Button 
				    onClick={() => window.location.href = '/editor'}
                    size="lg"
                    variant="outline"
                    className="px-8 py-6 text-lg border-slate-400/30 text-white hover:bg-slate-700/20 glass-light"
                  >
                    <i className="fas fa-edit mr-2"></i>
                    Редактор страницы
                  </Button>
              </>
            ) : (
              /* Guest actions */
              <>
                <Link href="/register">
                  <Button 
                    size="lg"
                    className="px-8 py-6 text-lg btn-dark-gradient text-white border-0 shadow-xl"
                  >
                    <i className="fas fa-magic mr-2"></i>
                    Начать бесплатно
                  </Button>
                </Link>
                <Link href="/demo">
                  <Button 
                    size="lg"
                    variant="outline"
                    className="px-8 py-6 text-lg border-slate-400/30 text-white hover:bg-slate-700/20 glass-light"
                  >
                    <i className="fas fa-eye mr-2"></i>
                    Посмотреть демо
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>

        {/* Features */}
        <div className="mt-24 grid md:grid-cols-3 gap-8">
          <div className="glass-morphism p-8 rounded-2xl text-center card-hover">
            <div className="w-16 h-16 bg-gradient-to-br from-slate-600 to-slate-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
              <i className="fas fa-palette text-white text-2xl"></i>
            </div>
            <h3 className="text-xl font-bold text-white mb-4">Полная кастомизация</h3>
            <p className="text-slate-300">
              Настройте каждый элемент: цвета, размеры, эффекты blur, прозрачность и многое другое
            </p>
          </div>

          <div className="glass-morphism p-8 rounded-2xl text-center card-hover">
            <div className="w-16 h-16 bg-gradient-to-br from-slate-500 to-slate-400 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
              <i className="fas fa-mobile-alt text-white text-2xl"></i>
            </div>
            <h3 className="text-xl font-bold text-white mb-4">Адаптивный дизайн</h3>
            <p className="text-slate-300">
              Ваша страница будет отлично выглядеть на всех устройствах: от телефона до десктопа
            </p>
          </div>

          <div className="glass-morphism p-8 rounded-2xl text-center card-hover">
            <div className="w-16 h-16 bg-gradient-to-br from-slate-700 to-slate-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
              <i className="fas fa-link text-white text-2xl"></i>
            </div>
            <h3 className="text-xl font-bold text-white mb-4">Социальные сети</h3>
            <p className="text-slate-300">
              Добавьте ссылки на все ваши социальные сети с красивыми иконками и анимациями
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}