import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { useInvites } from "@/hooks/use-invites";
import { useToast } from "@/hooks/use-toast";
import { Gift, Check, X } from "lucide-react";

export default function Register() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    inviteCode: "",
  });
  const [loading, setLoading] = useState(false);
  const [inviteValidated, setInviteValidated] = useState<boolean | null>(null);
  const { signUp } = useAuth();
  const { validateInvite, isValidatingInvite } = useInvites();
  const { toast } = useToast();

  const handleInviteValidation = async (code: string) => {
    if (!code.trim()) {
      setInviteValidated(null);
      return;
    }

    validateInvite(code, {
      onSuccess: (isValid) => {
        setInviteValidated(isValid);
        if (!isValid) {
          toast({
            title: "Недействительный инвайт",
            description: "Инвайт-код недействителен или истек",
            variant: "destructive",
          });
        }
      },
      onError: () => {
        setInviteValidated(false);
        toast({
          title: "Ошибка проверки",
          description: "Не удалось проверить инвайт-код",
          variant: "destructive",
        });
      },
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.inviteCode.trim()) {
      toast({
        title: "Ошибка",
        description: "Для регистрации требуется инвайт-код",
        variant: "destructive",
      });
      return;
    }

    if (inviteValidated !== true) {
      toast({
        title: "Ошибка",
        description: "Проверьте правильность инвайт-кода",
        variant: "destructive",
      });
      return;
    }
    
    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Ошибка",
        description: "Пароли не совпадают",
        variant: "destructive",
      });
      return;
    }

    if (formData.password.length < 6) {
      toast({
        title: "Ошибка",
        description: "Пароль должен содержать минимум 6 символов",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      await signUp(formData.email, formData.password, {
        username: formData.username,
        email: formData.email,
      }, formData.inviteCode);

      toast({
        title: "Регистрация успешна!",
        description: "Добро пожаловать в Personal Curator",
      });

      setLocation("/dashboard");
    } catch (error: any) {
      toast({
        title: "Ошибка регистрации",
        description: error.message || "Не удалось создать аккаунт",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUsernameChange = (value: string) => {
    const cleaned = value.toLowerCase().replace(/[^a-z0-9]/g, '');
    setFormData({ ...formData, username: cleaned });
  };

  const handleInviteCodeChange = (value: string) => {
    const cleaned = value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    setFormData({ ...formData, inviteCode: cleaned });
    
    if (cleaned.length === 8) {
      handleInviteValidation(cleaned);
    } else {
      setInviteValidated(null);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-dark-gradient">
      {/* Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-slate-600/8 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-slate-500/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '-3s' }}></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-slate-700/6 rounded-full blur-3xl animate-float" style={{ animationDelay: '-1.5s' }}></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-50 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/">
            <div className="glass-morphism px-6 py-3 rounded-2xl cursor-pointer">
              <h1 className="text-2xl font-bold text-white">Personal Curator</h1>
            </div>
          </Link>
          <div className="flex gap-4">
            <Link href="/login">
              <Button variant="ghost" className="glass-light text-white hover:bg-slate-700/20 border-slate-400/20">
                Войти
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="relative z-10 flex items-center justify-center min-h-[calc(100vh-100px)] p-4">
        <Card className="w-full max-w-md glass-dark border-slate-400/10 card-hover">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-white">
              Создать аккаунт
            </CardTitle>
            <p className="text-slate-300">
              Присоединяйтесь к Personal Curator
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Invite Code */}
              <div>
                <Label htmlFor="inviteCode" className="text-slate-200 flex items-center">
                  <Gift className="w-4 h-4 mr-2 text-slate-400" />
                  Инвайт-код
                </Label>
                <div className="relative">
                  <Input
                    id="inviteCode"
                    type="text"
                    value={formData.inviteCode}
                    onChange={(e) => handleInviteCodeChange(e.target.value)}
                    className="bg-slate-800/30 border-slate-400/20 text-white placeholder-slate-400 pr-10"
                    placeholder="XXXXXXXX"
                    maxLength={8}
                    required
                  />
                  {formData.inviteCode.length === 8 && (
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                      {isValidatingInvite ? (
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      ) : inviteValidated === true ? (
                        <Check className="w-4 h-4 text-green-400" />
                      ) : inviteValidated === false ? (
                        <X className="w-4 h-4 text-red-400" />
                      ) : null}
                    </div>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Получите инвайт-код от друга или дождитесь invite wave
                </p>
              </div>

              <div>
                <Label htmlFor="username" className="text-slate-200">Имя пользователя</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400">@</span>
                  <Input
                    id="username"
                    type="text"
                    value={formData.username}
                    onChange={(e) => handleUsernameChange(e.target.value)}
                    className="bg-slate-800/30 border-slate-400/20 text-white placeholder-slate-400 pl-8"
                    placeholder="alexsmith"
                    required
                  />
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  curator.bio/{formData.username || 'username'}
                </p>
              </div>
              
              <div>
                <Label htmlFor="email" className="text-slate-200">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-slate-800/30 border-slate-400/20 text-white placeholder-slate-400"
                  placeholder="alex@example.com"
                  required
                />
              </div>

              <div>
                <Label htmlFor="password" className="text-slate-200">Пароль</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="bg-slate-800/30 border-slate-400/20 text-white placeholder-slate-400"
                  placeholder="Минимум 6 символов"
                  required
                />
              </div>

              <div>
                <Label htmlFor="confirmPassword" className="text-slate-200">Подтвердите пароль</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="bg-slate-800/30 border-slate-400/20 text-white placeholder-slate-400"
                  placeholder="Повторите пароль"
                  required
                />
              </div>

              <Button 
                type="submit" 
                className="w-full py-6 text-lg btn-dark-gradient text-white border-0 shadow-lg"
                disabled={loading || inviteValidated !== true}
              >
                {loading ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Создаем аккаунт...
                  </>
                ) : (
                  <>
                    <i className="fas fa-user-plus mr-2"></i>
                    Создать аккаунт
                  </>
                )}
              </Button>
            </form>

            <div className="text-center mt-6">
              <p className="text-slate-400 text-sm">
                Уже есть аккаунт?{" "}
                <Link href="/login" className="text-slate-300 hover:text-white transition-colors">
                  Войти
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}