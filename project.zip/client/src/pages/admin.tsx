import { AdminRoute } from "@/components/admin/admin-route";
import { AdminStats } from "@/components/admin/admin-stats";
import { UserManagementTable } from "@/components/admin/user-management-table";
import { InviteManagement } from "@/components/admin/invite-management";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Shield } from "lucide-react";

export default function AdminPanel() {
  return (
    <AdminRoute>
      <div className="min-h-screen bg-dark-gradient">
        {/* Navigation */}
        <nav className="glass-morphism border-b border-slate-400/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 admin-gradient rounded-lg flex items-center justify-center shadow-lg">
                  <Shield className="text-white text-sm" />
                </div>
                <h1 className="text-xl font-bold text-white">Админ-панель</h1>
              </div>
              
              <Link href="/dashboard">
                <Button
                  variant="ghost"
                  className="text-slate-200 hover:text-white border-slate-400/20 glass-light"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Назад в панель
                </Button>
              </Link>
            </div>
          </div>
        </nav>

        {/* Background Elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-500/5 rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-orange-500/8 rounded-full blur-3xl animate-float" style={{ animationDelay: '-3s' }}></div>
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-yellow-500/6 rounded-full blur-3xl animate-float" style={{ animationDelay: '-1.5s' }}></div>
          <div className="absolute top-3/4 left-1/6 w-72 h-72 bg-slate-600/8 rounded-full blur-3xl animate-float" style={{ animationDelay: '-2s' }}></div>
        </div>

        {/* Main Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 py-8">
          <div className="space-y-8">
            {/* Header */}
            <div className="text-center">
              <h1 className="text-3xl font-bold text-white mb-2">
                Панель администратора
              </h1>
              <p className="text-slate-300">
                Управление пользователями, инвайтами и мониторинг системы
              </p>
            </div>

            {/* Statistics */}
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">Статистика</h2>
              <AdminStats />
            </div>

            {/* Invite Management */}
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">Управление инвайтами</h2>
              <InviteManagement />
            </div>

            {/* User Management */}
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">Управление пользователями</h2>
              <UserManagementTable />
            </div>
          </div>
        </div>
      </div>
    </AdminRoute>
  );
}