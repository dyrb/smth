import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { supabase } from "@/lib/supabase";
import BioCard from "@/components/bio-card";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import type { User, BioPage, DesignSettings } from "@shared/schema";

export default function BioPage() {
  const [match, params] = useRoute("/:pageUrl");
  const pageUrl = params?.pageUrl;

  const { data, isLoading, error } = useQuery({
    queryKey: ["public-bio", pageUrl],
    queryFn: async (): Promise<{ user: User; bioPage: BioPage } | null> => {
      if (!pageUrl) return null;

      // Get user by page URL
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("*")
        .eq("page_url", pageUrl)
        .eq("is_public", true)
        .maybeSingle();

      if (userError) throw userError;
      if (!userData) return null;

      // Get bio page
      const { data: bioPageData, error: bioError } = await supabase
        .from("bio_pages")
        .select("*")
        .eq("user_id", userData.id)
        .eq("is_active", true)
        .maybeSingle();

      if (bioError) throw bioError;
      if (!bioPageData) return null;

      // Increment view count
      await supabase
        .from("users")
        .update({ view_count: (userData.view_count || 0) + 1 })
        .eq("id", userData.id);

      // Transform snake_case to camelCase for user
      const user: User = {
        ...userData,
        backgroundImage: userData.background_image,
        viewCount: (userData.view_count || 0) + 1,
        pageUrl: userData.page_url,
        isPublic: userData.is_public,
        userNumber: userData.user_number,
        createdAt: userData.created_at,
        updatedAt: userData.updated_at,
      };

      // Transform snake_case to camelCase for bioPage
      const bioPage: BioPage = {
        ...bioPageData,
        userId: bioPageData.user_id,
        customSettings: bioPageData.custom_settings,
        socialLinks: bioPageData.social_links,
        isActive: bioPageData.is_active,
        createdAt: bioPageData.created_at,
        updatedAt: bioPageData.updated_at,
      };

      return { user, bioPage };
    },
    enabled: !!pageUrl,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="glass-morphism p-8 rounded-2xl">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto"></div>
          <p className="text-white mt-4">Загрузка страницы...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md glass-dark border-white/10">
          <CardContent className="pt-6">
            <div className="flex mb-4 gap-2 items-center justify-center">
              <AlertCircle className="h-8 w-8 text-red-400" />
              <h1 className="text-2xl font-bold text-white">Страница не найдена</h1>
            </div>
            <p className="mt-4 text-sm text-white/60 text-center">
              Возможно, страница была удалена или URL указан неверно.
            </p>
            <div className="mt-6 text-center">
              <a 
                href="/"
                className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg hover:from-indigo-600 hover:to-purple-700 transition-all"
              >
                Создать свою страницу
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { user, bioPage } = data;
  const settings = bioPage.customSettings as DesignSettings;

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Container with proper layering */}
      <div className="fixed inset-0">
        {/* Background Image Layer with Blur */}
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `url(${user.backgroundImage || "https://images.unsplash.com/photo-1557683316-973673baf926?ixlib=rb-4.0.3&w=1200&h=800&fit=crop"})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            filter: settings?.backgroundBlur ? `blur(${settings.backgroundBlur}px)` : 'blur(5px)',
          }}
        ></div>
        
        {/* Background Color Overlay */}
        <div 
          className="absolute inset-0"
          style={{
            backgroundColor: settings?.backgroundColor 
              ? `rgba(${settings.backgroundColor.replace('#', '').match(/.{2}/g)?.map(hex => parseInt(hex, 16)).join(', ')}, ${(settings.backgroundOpacity || 100) / 100})`
              : 'rgba(26, 26, 46, 0.8)',
          }}
        ></div>
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <BioCard 
          user={user} 
          bioPage={bioPage}
          isPublic={true}
        />
      </div>

      {/* Powered by */}
      <div className="fixed bottom-4 right-4 z-20">
        <a 
          href="/"
          className="glass-morphism px-4 py-2 rounded-lg text-white/60 hover:text-white transition-colors text-sm"
        >
          <i className="fas fa-heart text-red-400 mr-2"></i>
          Создано с Personal Curator
        </a>
      </div>
    </div>
  );
}