import { useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';

export function AuthSessionManager() {
  const { user, session } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    // Handle session expiration warnings
    if (session?.expires_at) {
      const expiresAt = new Date(session.expires_at * 1000);
      const now = new Date();
      const timeUntilExpiry = expiresAt.getTime() - now.getTime();
      
      // Warn user 5 minutes before session expires
      const warningTime = timeUntilExpiry - (5 * 60 * 1000);
      
      if (warningTime > 0) {
        const warningTimeout = setTimeout(() => {
          toast({
            title: "Сессия истекает",
            description: "Ваша сессия истечет через 5 минут. Сохраните изменения.",
            variant: "destructive",
          });
        }, warningTime);

        return () => clearTimeout(warningTimeout);
      }
    }
  }, [session, toast]);

  useEffect(() => {
    // Log session events for debugging
    if (user && session) {
      console.log('User session active:', {
        email: user.email,
        expiresAt: session.expires_at ? new Date(session.expires_at * 1000) : 'No expiry',
        tokenType: session.token_type
      });
    }
  }, [user, session]);

  // This component doesn't render anything, it just manages session state
  return null;
}