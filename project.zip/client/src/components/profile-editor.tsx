import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";
import { UserPlus, Gift } from "lucide-react";
import type { User } from "@shared/schema";

interface ProfileEditorProps {
  user?: User;
  onUserUpdate: () => void;
}

export default function ProfileEditor({ user, onUserUpdate }: ProfileEditorProps) {
  const { user: authUser } = useAuth();
  const [formData, setFormData] = useState<{
    username: string;
    bio: string;
    email: string;
    avatar: string;
    banner: string;
    backgroundImage: string;
  }>({
    username: user?.username || "",
    bio: user?.bio || "",
    email: user?.email || "",
    avatar: user?.avatar || "",
    banner: user?.banner || "",
    backgroundImage: user?.backgroundImage || "",
  });
  const { toast } = useToast();

  // Get detailed user info including who invited them
  const { data: detailedUser } = useQuery({
    queryKey: ["detailed-user", authUser?.id],
    queryFn: async () => {
      if (!authUser?.id) return null;
      
      const { data, error } = await supabase
        .from("users")
        .select(`
          *,
          invited_by_user:invited_by(username, avatar, user_number)
        `)
        .eq("id", authUser.id)
        .single();

      if (error) throw error;
      return data;
    },
    enabled: !!authUser?.id,
  });

  const updateUserMutation = useMutation({
    mutationFn: async (userData: Partial<any>) => {
      if (!authUser?.id) throw new Error("User not authenticated");
      
      const { error } = await supabase
        .from("users")
        .update({
          username: userData.username,
          bio: userData.bio,
          email: userData.email,
          avatar: userData.avatar,
          banner: userData.banner,
          background_image: userData.backgroundImage,
          updated_at: new Date().toISOString(),
        })
        .eq("id", authUser.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Профиль обновлен!",
        description: "Изменения сохранены успешно",
      });
      onUserUpdate();
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось обновить профиль",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserMutation.mutate({
      username: formData.username,
      bio: formData.bio,
      email: formData.email,
      avatar: formData.avatar,
      banner: formData.banner,
      backgroundImage: formData.backgroundImage,
    });
  };

  const handleUsernameChange = (value: string) => {
    const cleaned = value.toLowerCase().replace(/[^a-z0-9]/g, '');
    setFormData({ ...formData, username: cleaned });
  };

  return (
    <div className="space-y-6">
      <Card className="glass-dark border-white/10 card-hover">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <i className="fas fa-user-edit mr-3 text-cyan-400"></i>
            Профиль
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Invited by info */}
          {detailedUser?.invited_by_user ? (
            <div className="mb-6 p-4 glass-light border border-purple-500/20 rounded-lg">
              <p className="text-purple-300 font-medium flex items-center text-sm mb-3">
                <UserPlus className="w-4 h-4 mr-2" />
                Приглашен пользователем
              </p>
              <div className="flex items-center space-x-3">
                <img
                  src={detailedUser.invited_by_user.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=100&h=100&fit=crop&crop=face"}
                  alt={detailedUser.invited_by_user.username}
                  className="w-10 h-10 rounded-full object-cover border-2 border-purple-400/30"
                />
                <div>
                  <p className="text-white font-medium">@{detailedUser.invited_by_user.username}</p>
                  <p className="text-white/60 text-xs">ID: #{detailedUser.invited_by_user.user_number}</p>
                </div>
              </div>
            </div>
          ) : detailedUser?.invited_by ? (
            <div className="mb-6 p-4 glass-light border border-blue-500/20 rounded-lg">
              <p className="text-blue-300 font-medium flex items-center text-sm mb-3">
                <UserPlus className="w-4 h-4 mr-2" />
                Приглашен пользователем
              </p>
              <p className="text-blue-200/60 text-xs mt-1">
                ID: {detailedUser.invited_by}
              </p>
            </div>
          ) : (
            <div className="mb-6 p-4 glass-light border border-blue-500/20 rounded-lg">
              <p className="text-blue-300 font-medium flex items-center text-sm">
                <Gift className="w-4 h-4 mr-2" />
                Оригинальный пользователь
              </p>
              <p className="text-blue-200/60 text-xs mt-1">
                Зарегистрировался без инвайт-кода
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="username" className="text-white/80">Имя пользователя</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60">@</span>
                <Input
                  id="username"
                  value={formData.username}
                  onChange={(e) => handleUsernameChange(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder-white/50 pl-8"
                  placeholder="alexsmith"
                />
              </div>
              <p className="text-xs text-white/60 mt-1">
                curator.bio/{formData.username || 'username'}
              </p>
            </div>
            
            <div>
              <Label htmlFor="bio" className="text-white/80">Описание</Label>
              <Textarea
                id="bio"
                rows={4}
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                className="bg-white/10 border-white/20 text-white placeholder-white/50 resize-none"
                placeholder="Расскажите о себе..."
              />
            </div>
            
            <div>
              <Label htmlFor="email" className="text-white/80">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="bg-white/10 border-white/20 text-white placeholder-white/50"
                placeholder="alex@example.com"
              />
            </div>
            
            <div>
              <Label className="text-white/80">Аватар</Label>
              <div className="flex items-center space-x-4 mt-2">
                <img 
                  src={user?.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=100&h=100&fit=crop&crop=face"} 
                  alt="Current Avatar" 
                  className="w-12 h-12 rounded-full border-2 border-white/20"
                />
                <Input
                  type="url"
                  value={formData.avatar || ""}
                  onChange={(e) => setFormData({ ...formData, avatar: e.target.value })}
                  className="bg-white/10 border-white/20 text-white placeholder-white/50 flex-1"
                  placeholder="URL аватара"
                />
              </div>
            </div>

            <div>
              <Label className="text-white/80">Баннер</Label>
              <div className="mt-2">
                {user?.banner && (
                  <div className="mb-2">
                    <img 
                      src={user.banner} 
                      alt="Current Banner" 
                      className="w-full h-20 object-cover rounded-lg border border-white/20"
                    />
                  </div>
                )}
                <Input
                  type="url"
                  value={formData.banner || ""}
                  onChange={(e) => setFormData({ ...formData, banner: e.target.value })}
                  className="bg-white/10 border-white/20 text-white placeholder-white/50"
                  placeholder="URL баннера"
                />
              </div>
            </div>

            <div>
              <Label className="text-white/80">Фоновое изображение</Label>
              <div className="mt-2">
                {user?.backgroundImage && (
                  <div className="mb-2">
                    <img 
                      src={user.backgroundImage} 
                      alt="Background" 
                      className="w-full h-16 object-cover rounded-lg border border-white/20"
                    />
                  </div>
                )}
                <Input
                  type="url"
                  value={formData.backgroundImage || ""}
                  onChange={(e) => setFormData({ ...formData, backgroundImage: e.target.value })}
                  className="bg-white/10 border-white/20 text-white placeholder-white/50"
                  placeholder="URL фонового изображения"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={updateUserMutation.isPending}
              className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700"
            >
              {updateUserMutation.isPending ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Сохранение...
                </>
              ) : (
                <>
                  <i className="fas fa-save mr-2"></i>
                  Сохранить профиль
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="space-y-3">
        <Button
          onClick={() => user?.pageUrl && window.open(`/${user.pageUrl}`, '_blank')}
          className="w-full glass-light text-white border border-white/20 hover:bg-white/20"
          variant="outline"
          disabled={!user?.pageUrl}
        >
          <i className="fas fa-external-link-alt mr-2"></i>
          Открыть страницу
        </Button>
        
        <Button
          onClick={() => {
            if (user?.pageUrl) {
              navigator.clipboard.writeText(`${window.location.origin}/${user.pageUrl}`);
              toast({
                title: "Ссылка скопирована!",
                description: "Ссылка на вашу био-страницу скопирована в буфер обмена",
              });
            }
          }}
          className="w-full glass-light text-white/80 border border-white/10 hover:bg-white/10"
          variant="outline"
          disabled={!user?.pageUrl}
        >
          <i className="fas fa-share mr-2"></i>
          Поделиться
        </Button>
      </div>
    </div>
  );
}