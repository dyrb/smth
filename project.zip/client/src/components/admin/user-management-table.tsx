import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAdmin } from "@/hooks/use-admin";
import { useInvites } from "@/hooks/use-invites";
import { useToast } from "@/hooks/use-toast";
import { BanUserDialog } from "./ban-user-dialog";
import { Search, Shield, ShieldCheck, Ban, UserCheck, Eye, Calendar, Trash2, Gift, UserPlus } from "lucide-react";
import type { UserWithBanInfo } from "@shared/admin-schema";

export function UserManagementTable() {
  const [searchTerm, setSearchTerm] = useState("");
  const { users, isLoadingUsers, unbanUser, changeUserRole, isUnbanningUser, isChangingRole } = useAdmin();
  const { purgeUserInvites, isPurgingInvites, giveInviteToUser, isGivingInvite } = useInvites();
  const { toast } = useToast();

  const filteredUsers = users?.filter(user =>
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const handleUnban = (userId: string, username: string) => {
    unbanUser(userId, {
      onSuccess: () => {
        toast({
          title: "Пользователь разблокирован",
          description: `@${username} успешно разблокирован`,
        });
      },
      onError: (error: any) => {
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось разблокировать пользователя",
          variant: "destructive",
        });
      },
    });
  };

  const handleRoleChange = (userId: string, username: string, newRole: 'user' | 'admin') => {
    changeUserRole({ userId, role: newRole }, {
      onSuccess: () => {
        toast({
          title: "Роль изменена",
          description: `@${username} теперь ${newRole === 'admin' ? 'администратор' : 'пользователь'}`,
        });
      },
      onError: (error: any) => {
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось изменить роль",
          variant: "destructive",
        });
      },
    });
  };

  const handlePurgeInvites = (userId: string, username: string) => {
    purgeUserInvites(userId, {
      onSuccess: (count) => {
        toast({
          title: "Инвайты удалены",
          description: `Удалено ${count} неиспользованных инвайтов у @${username}`,
        });
      },
      onError: (error: any) => {
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось удалить инвайты",
          variant: "destructive",
        });
      },
    });
  };

  const handleGiveInvite = (userId: string, username: string) => {
    giveInviteToUser(userId, {
      onSuccess: (inviteCode) => {
        toast({
          title: "Инвайт выдан",
          description: `@${username} получил новый инвайт-код: ${inviteCode}`,
        });
      },
      onError: (error: any) => {
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось выдать инвайт",
          variant: "destructive",
        });
      },
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getBanStatusBadge = (user: UserWithBanInfo) => {
    if (!user.banInfo?.isBanned) {
      return <Badge variant="secondary" className="bg-green-500/20 text-green-400">Активен</Badge>;
    }

    const isExpired = user.banInfo.expiresAt && new Date(user.banInfo.expiresAt) <= new Date();
    if (isExpired) {
      return <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-400">Бан истек</Badge>;
    }

    return (
      <Badge variant="destructive" className="bg-red-500/20 text-red-400">
        {user.banInfo.banType === 'permanent' ? 'Постоянный бан' : 'Временный бан'}
      </Badge>
    );
  };

  if (isLoadingUsers) {
    return (
      <Card className="glass-dark border-slate-400/10">
        <CardContent className="pt-6">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-300"></div>
            <span className="ml-3 text-white">Загрузка пользователей...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-dark border-slate-400/10 card-hover">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Shield className="w-5 h-5 mr-3 text-slate-400" />
          Управление пользователями
        </CardTitle>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input
            placeholder="Поиск по username или email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-slate-800/30 border-slate-400/20 text-white placeholder-slate-400"
          />
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {filteredUsers.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              {searchTerm ? "Пользователи не найдены" : "Нет пользователей"}
            </div>
          ) : (
            filteredUsers.map((user) => (
              <div
                key={user.id}
                className="glass-light p-4 rounded-lg border border-slate-500/10"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <img
                      src={user.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=100&h=100&fit=crop&crop=face"}
                      alt={user.username}
                      className="w-12 h-12 rounded-full object-cover border-2 border-slate-400/20"
                    />
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="text-white font-medium">@{user.username}</h3>
                        {user.role === 'admin' && (
                          <ShieldCheck className="w-4 h-4 text-yellow-400" />
                        )}
                        <span className="text-slate-400 text-sm">#{user.userNumber}</span>
                      </div>
                      
                      <p className="text-slate-300 text-sm mb-2">{user.email}</p>
                      
                      <div className="flex items-center space-x-4 text-xs text-slate-400">
                        <span className="flex items-center">
                          <Eye className="w-3 h-3 mr-1" />
                          {user.viewCount} просмотров
                        </span>
                        <span className="flex items-center">
                          <Calendar className="w-3 h-3 mr-1" />
                          {formatDate(user.createdAt)}
                        </span>
                      </div>
                      
                      {/* Show invite info if user was invited */}
                      {user.invitedByUsername && user.invitedByUserNumber ? (
                        <div className="mt-2 p-2 bg-blue-500/10 border border-blue-500/20 rounded text-xs">
                          <p className="text-blue-400 font-medium flex items-center">
                            <UserPlus className="w-3 h-3 mr-1" />
                            Invited by @{user.invitedByUsername} (#{user.invitedByUserNumber})
                          </p>
                        </div>
                      ) : user.invitedBy ? (
                        <div className="mt-2 p-2 bg-blue-500/10 border border-blue-500/20 rounded text-xs">
                          <p className="text-blue-400 font-medium flex items-center">
                            <UserPlus className="w-3 h-3 mr-1" />
                            Invited by user ID: {user.invitedBy}
                          </p>
                        </div>
                      ) : (
                        <div className="mt-2 p-2 bg-purple-500/10 border border-purple-500/20 rounded text-xs">
                          <p className="text-purple-400 font-medium flex items-center">
                            <Gift className="w-3 h-3 mr-1" />
                            Оригинальный пользователь
                          </p>
                        </div>
                      )}
                      
                      {user.banInfo?.isBanned && (
                        <div className="mt-2 p-2 bg-red-500/10 border border-red-500/20 rounded text-xs">
                          <p className="text-red-400 font-medium">Причина бана: {user.banInfo.reason}</p>
                          {user.banInfo.expiresAt && (
                            <p className="text-red-300">
                              Истекает: {formatDate(user.banInfo.expiresAt)}
                            </p>
                          )}
                          {user.banInfo.bannedByUsername && (
                            <p className="text-red-300">
                              Заблокировал: @{user.banInfo.bannedByUsername}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex flex-col items-end space-y-2">
                    {getBanStatusBadge(user)}
                    
                    <div className="flex flex-wrap gap-2">
                      {user.banInfo?.isBanned ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleUnban(user.id, user.username)}
                          disabled={isUnbanningUser}
                          className="border-green-500/50 text-green-400 hover:bg-green-500/10"
                        >
                          <UserCheck className="w-4 h-4 mr-1" />
                          Разблокировать
                        </Button>
                      ) : (
                        <BanUserDialog userId={user.id} username={user.username} />
                      )}
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRoleChange(
                          user.id, 
                          user.username, 
                          user.role === 'admin' ? 'user' : 'admin'
                        )}
                        disabled={isChangingRole}
                        className="border-blue-500/50 text-blue-400 hover:bg-blue-500/10"
                      >
                        {user.role === 'admin' ? (
                          <>
                            <Shield className="w-4 h-4 mr-1" />
                            Снять админа
                          </>
                        ) : (
                          <>
                            <ShieldCheck className="w-4 h-4 mr-1" />
                            Сделать админом
                          </>
                        )}
                      </Button>

                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleGiveInvite(user.id, user.username)}
                        disabled={isGivingInvite}
                        className="border-green-500/50 text-green-400 hover:bg-green-500/10"
                      >
                        <Gift className="w-4 h-4 mr-1" />
                        Выдать инвайт
                      </Button>

                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handlePurgeInvites(user.id, user.username)}
                        disabled={isPurgingInvites}
                        className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Purge Invites
                      </Button>
                      
                      {user.pageUrl && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => window.open(`/${user.pageUrl}`, '_blank')}
                          className="text-slate-400 hover:text-white hover:bg-slate-700/20"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}