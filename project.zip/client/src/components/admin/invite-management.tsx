import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useInvites } from "@/hooks/use-invites";
import { useToast } from "@/hooks/use-toast";
import { Zap, Trash2, Users, Gift } from "lucide-react";

export function InviteManagement() {
  const { createInviteWave, isCreatingInviteWave, purgeUserInvites, isPurgingInvites } = useInvites();
  const { toast } = useToast();
  const [selectedUserId, setSelectedUserId] = useState<string>("");

  const handleInviteWave = () => {
    createInviteWave(undefined, {
      onSuccess: (count) => {
        toast({
          title: "Invite Wave создана!",
          description: `Выдано ${count} инвайтов всем пользователям`,
        });
      },
      onError: (error: any) => {
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось создать invite wave",
          variant: "destructive",
        });
      },
    });
  };

  const handlePurgeInvites = (userId: string, username: string) => {
    if (!userId) return;
    
    purgeUserInvites(userId, {
      onSuccess: (count) => {
        toast({
          title: "Инвайты удалены",
          description: `Удалено ${count} неиспользованных инвайтов у @${username}`,
        });
      },
      onError: (error: any) => {
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось удалить инвайты",
          variant: "destructive",
        });
      },
    });
  };

  return (
    <Card className="glass-dark border-slate-400/10 card-hover">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Gift className="w-5 h-5 mr-3 text-slate-400" />
          Управление инвайтами
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Invite Wave */}
        <div className="glass-light p-6 rounded-lg border border-slate-500/10">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="text-white font-medium mb-2 flex items-center">
                <Zap className="w-5 h-5 mr-2 text-yellow-400" />
                Invite Wave
              </h3>
              <p className="text-slate-300 text-sm mb-4">
                Выдать по одному инвайт-коду каждому активному пользователю. 
                Инвайты действительны в течение 1 года.
              </p>
              <div className="flex items-center space-x-2 text-xs text-slate-400">
                <Users className="w-4 h-4" />
                <span>Будет выдано всем незабаненным пользователям</span>
              </div>
            </div>
            <Button
              onClick={handleInviteWave}
              disabled={isCreatingInviteWave}
              className="bg-gradient-to-r from-yellow-600 to-orange-700 hover:from-yellow-700 hover:to-orange-800 ml-4 text-white shadow-lg"
            >
              {isCreatingInviteWave ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Создание...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Создать Wave
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Quick Actions Info */}
        <div className="glass-light p-6 rounded-lg border border-slate-500/10">
          <div className="flex items-start space-x-4">
            <div className="w-10 h-10 bg-gradient-to-r from-red-600 to-pink-700 rounded-lg flex items-center justify-center shadow-lg">
              <Trash2 className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-white font-medium mb-2">Purge инвайтов</h3>
              <p className="text-slate-300 text-sm">
                Для удаления всех неиспользованных инвайтов конкретного пользователя, 
                используйте кнопку "Purge Invites" в таблице управления пользователями.
              </p>
            </div>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="glass-light p-4 rounded-lg border border-slate-500/10 text-center">
            <div className="text-2xl font-bold text-white mb-1">∞</div>
            <div className="text-slate-400 text-sm">Лимит инвайтов</div>
          </div>
          <div className="glass-light p-4 rounded-lg border border-slate-500/10 text-center">
            <div className="text-2xl font-bold text-yellow-400 mb-1">365</div>
            <div className="text-slate-400 text-sm">Дней действия</div>
          </div>
          <div className="glass-light p-4 rounded-lg border border-slate-500/10 text-center">
            <div className="text-2xl font-bold text-green-400 mb-1">8</div>
            <div className="text-slate-400 text-sm">Символов в коде</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}