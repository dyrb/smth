import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAdmin } from "@/hooks/use-admin";
import { Users, FileText, Ban, TrendingUp, Calendar, Clock } from "lucide-react";

export function AdminStats() {
  const { stats, isLoadingStats } = useAdmin();

  if (isLoadingStats) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="glass-dark border-slate-400/10">
            <CardContent className="pt-6">
              <div className="animate-pulse">
                <div className="h-4 bg-slate-600/20 rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-slate-600/20 rounded w-1/2"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statCards = [
    {
      title: "Всего пользователей",
      value: stats?.totalUsers || 0,
      icon: Users,
      color: "text-slate-400",
      bgColor: "bg-slate-500/20",
    },
    {
      title: "Активные био-страницы",
      value: stats?.activeBioPages || 0,
      icon: FileText,
      color: "text-green-400",
      bgColor: "bg-green-500/20",
    },
    {
      title: "Активные баны",
      value: stats?.activeBans || 0,
      icon: Ban,
      color: "text-red-400",
      bgColor: "bg-red-500/20",
    },
    {
      title: "Новых сегодня",
      value: stats?.newUsersToday || 0,
      icon: TrendingUp,
      color: "text-yellow-400",
      bgColor: "bg-yellow-500/20",
    },
    {
      title: "Новых за неделю",
      value: stats?.newUsersThisWeek || 0,
      icon: Calendar,
      color: "text-purple-400",
      bgColor: "bg-purple-500/20",
    },
    {
      title: "Новых за месяц",
      value: stats?.newUsersThisMonth || 0,
      icon: Clock,
      color: "text-indigo-400",
      bgColor: "bg-indigo-500/20",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {statCards.map((stat, index) => (
        <Card key={index} className="glass-dark border-slate-400/10 card-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-200">
              {stat.title}
            </CardTitle>
            <div className={`p-2 rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stat.value}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}