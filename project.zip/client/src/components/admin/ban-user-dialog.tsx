import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAdmin } from "@/hooks/use-admin";
import { useToast } from "@/hooks/use-toast";
import { Ban } from "lucide-react";
import type { CreateBanRequest } from "@shared/admin-schema";

interface BanUserDialogProps {
  userId: string;
  username: string;
  children?: React.ReactNode;
}

export function BanUserDialog({ userId, username, children }: BanUserDialogProps) {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState<CreateBanRequest>({
    userId,
    reason: "",
    banType: "temporary",
    duration: 7,
  });

  const { banUser, isBanningUser } = useAdmin();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.reason.trim()) {
      toast({
        title: "Ошибка",
        description: "Укажите причину бана",
        variant: "destructive",
      });
      return;
    }

    banUser(formData, {
      onSuccess: () => {
        toast({
          title: "Пользователь заблокирован",
          description: `@${username} успешно заблокирован`,
        });
        setOpen(false);
        setFormData({
          userId,
          reason: "",
          banType: "temporary",
          duration: 7,
        });
      },
      onError: (error: any) => {
        toast({
          title: "Ошибка",
          description: error.message || "Не удалось заблокировать пользователя",
          variant: "destructive",
        });
      },
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children || (
          <Button variant="destructive\" size="sm\" className="btn-danger-gradient">
            <Ban className="w-4 h-4 mr-2" />
            Заблокировать
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="glass-dark border-slate-400/10">
        <DialogHeader>
          <DialogTitle className="text-white">
            Заблокировать пользователя @{username}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="reason" className="text-slate-200">Причина блокировки</Label>
            <Textarea
              id="reason"
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              className="bg-slate-800/30 border-slate-400/20 text-white placeholder-slate-400"
              placeholder="Укажите причину блокировки..."
              rows={3}
              required
            />
          </div>

          <div>
            <Label htmlFor="banType" className="text-slate-200">Тип блокировки</Label>
            <Select
              value={formData.banType}
              onValueChange={(value: 'temporary' | 'permanent') => 
                setFormData({ ...formData, banType: value })
              }
            >
              <SelectTrigger className="bg-slate-800/30 border-slate-400/20 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="temporary">Временная</SelectItem>
                <SelectItem value="permanent">Постоянная</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {formData.banType === 'temporary' && (
            <div>
              <Label htmlFor="duration" className="text-slate-200">Длительность (дни)</Label>
              <Select
                value={formData.duration?.toString()}
                onValueChange={(value) => 
                  setFormData({ ...formData, duration: parseInt(value) })
                }
              >
                <SelectTrigger className="bg-slate-800/30 border-slate-400/20 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 день</SelectItem>
                  <SelectItem value="3">3 дня</SelectItem>
                  <SelectItem value="7">7 дней</SelectItem>
                  <SelectItem value="14">14 дней</SelectItem>
                  <SelectItem value="30">30 дней</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="flex-1 border-slate-400/20 text-white hover:bg-slate-700/20"
            >
              Отмена
            </Button>
            <Button
              type="submit"
              variant="destructive"
              disabled={isBanningUser}
              className="flex-1 btn-danger-gradient"
            >
              {isBanningUser ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Блокировка...
                </>
              ) : (
                <>
                  <Ban className="w-4 h-4 mr-2" />
                  Заблокировать
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}