import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useInvites } from "@/hooks/use-invites";
import { useToast } from "@/hooks/use-toast";
import { Copy, Users, UserCheck, Clock, ExternalLink } from "lucide-react";

export function InviteList() {
  const { userInvites, isLoadingUserInvites } = useInvites();
  const { toast } = useToast();
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const copyInviteCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(code);
      toast({
        title: "Скопировано!",
        description: "Инвайт-код скопирован в буфер обмена",
      });
      setTimeout(() => setCopiedCode(null), 2000);
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось скопировать код",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  const getInviteStatus = (invite: any) => {
    if (invite.isUsed) {
      return { label: "Использован", color: "bg-green-500/20 text-green-400" };
    }
    if (new Date(invite.expiresAt) <= new Date()) {
      return { label: "Истек", color: "bg-red-500/20 text-red-400" };
    }
    return { label: "Активен", color: "bg-blue-500/20 text-blue-400" };
  };

  if (isLoadingUserInvites) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="glass-dark border-slate-400/10">
            <CardContent className="pt-6">
              <div className="animate-pulse">
                <div className="h-4 bg-slate-600/20 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-slate-600/20 rounded w-1/2"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const unusedInvites = userInvites?.filter(invite => !invite.isUsed) || [];
  const usedInvites = userInvites?.filter(invite => invite.isUsed) || [];

  return (
    <div className="space-y-6">
      {/* Unused Invites */}
      <Card className="glass-dark border-slate-400/10 card-hover">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Users className="w-5 h-5 mr-3 text-slate-400" />
            Неиспользованные инвайты
          </CardTitle>
        </CardHeader>
        <CardContent>
          {unusedInvites.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>У вас нет активных инвайтов</p>
              <p className="text-sm">Дождитесь следующей invite wave</p>
            </div>
          ) : (
            <div className="space-y-3">
              {unusedInvites.map((invite) => {
                const status = getInviteStatus(invite);
                return (
                  <div
                    key={invite.id}
                    className="glass-light p-4 rounded-lg border border-slate-500/10 flex items-center justify-between"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-slate-600 to-slate-500 rounded-lg flex items-center justify-center shadow-lg">
                        <Users className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-white font-mono text-lg">{invite.code}</span>
                          <Badge className={status.color}>{status.label}</Badge>
                        </div>
                        <p className="text-slate-400 text-sm">
                          Получен {formatDate(invite.createdAt)} • Истекает {formatDate(invite.expiresAt)}
                        </p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyInviteCode(invite.code)}
                      className="border-slate-400/20 text-white hover:bg-slate-700/20"
                      disabled={new Date(invite.expiresAt) <= new Date()}
                    >
                      {copiedCode === invite.code ? (
                        <>
                          <UserCheck className="w-4 h-4 mr-2" />
                          Скопировано
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Копировать
                        </>
                      )}
                    </Button>
                  </div>
                );
              })}
              <div className="text-center text-slate-400 text-sm pt-2">
                Показано {unusedInvites.length} из {unusedInvites.length} результатов
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Invited Users */}
      <Card className="glass-dark border-slate-400/10 card-hover">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <UserCheck className="w-5 h-5 mr-3 text-green-400" />
            Приглашенные пользователи
          </CardTitle>
        </CardHeader>
        <CardContent>
          {usedInvites.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              <UserCheck className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Никто еще не использовал ваши инвайты</p>
              <p className="text-sm">Поделитесь инвайт-кодами с друзьями</p>
            </div>
          ) : (
            <div className="space-y-3">
              {usedInvites.map((invite) => (
                <div
                  key={invite.id}
                  className="glass-light p-4 rounded-lg border border-slate-500/10 flex items-center justify-between"
                >
                  <div className="flex items-center space-x-4">
                    <img
                      src={invite.usedByUser?.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=100&h=100&fit=crop&crop=face"}
                      alt={invite.usedByUser?.username}
                      className="w-10 h-10 rounded-full object-cover border-2 border-slate-400/20"
                    />
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-white font-medium">@{invite.usedByUser?.username}</span>
                        <Badge className="bg-green-500/20 text-green-400">Приглашен</Badge>
                      </div>
                      <p className="text-slate-400 text-sm">
                        Приглашен {invite.usedAt ? formatDate(invite.usedAt) : 'недавно'}
                      </p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => window.open(`/${invite.usedByUser?.username}`, '_blank')}
                    className="text-slate-400 hover:text-white hover:bg-slate-700/20"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}