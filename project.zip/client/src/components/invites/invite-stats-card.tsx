import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useInvites } from "@/hooks/use-invites";
import { Users, UserCheck, Clock, Zap } from "lucide-react";

export function InviteStatsCard() {
  const { inviteStats, isLoadingStats } = useInvites();

  if (isLoadingStats) {
    return (
      <Card className="glass-dark border-slate-400/10">
        <CardContent className="pt-6">
          <div className="animate-pulse">
            <div className="h-4 bg-slate-600/20 rounded w-3/4 mb-2"></div>
            <div className="h-8 bg-slate-600/20 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const statCards = [
    {
      title: "Всего инвайтов",
      value: inviteStats?.totalInvites || 0,
      icon: Users,
      color: "text-slate-400",
      bgColor: "bg-slate-500/20",
    },
    {
      title: "Использовано",
      value: inviteStats?.usedInvites || 0,
      icon: UserCheck,
      color: "text-green-400",
      bgColor: "bg-green-500/20",
    },
    {
      title: "Активных",
      value: inviteStats?.activeInvites || 0,
      icon: Zap,
      color: "text-yellow-400",
      bgColor: "bg-yellow-500/20",
    },
    {
      title: "Истекших",
      value: inviteStats?.expiredInvites || 0,
      icon: Clock,
      color: "text-red-400",
      bgColor: "bg-red-500/20",
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {statCards.map((stat, index) => (
        <Card key={index} className="glass-light border-slate-500/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-200">
              {stat.title}
            </CardTitle>
            <div className={`p-2 rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stat.value}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}