import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { DesignSettings } from "@shared/schema";
import { hexToRgb } from "@/lib/colors";

interface DesignPanelProps {
  settings: DesignSettings;
  onSettingsChange: (updates: Partial<DesignSettings>) => void;
}

export default function DesignPanel({ settings, onSettingsChange }: DesignPanelProps) {
  
  const ColorPicker = ({ value, onChange, label }: { value: string; onChange: (color: string) => void; label: string }) => (
    <div className="flex items-center justify-between">
      <Label className="text-sm text-white/80">{label}</Label>
      <input
        type="color"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="color-picker"
      />
    </div>
  );

  const RangeSlider = ({ 
    value, 
    onChange, 
    min, 
    max, 
    label, 
    unit = 'px' 
  }: { 
    value: number; 
    onChange: (value: number) => void; 
    min: number; 
    max: number; 
    label: string; 
    unit?: string;
  }) => (
    <div>
      <Label className="text-sm text-white/80 block mb-2">{label}</Label>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="slider-custom w-full"
      />
      <div className="text-xs text-white/60 mt-1">
        {value}{unit === '%' && value === 50 && label.includes('Avatar') ? '% (Circle)' : unit}
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Typography Settings */}
      <Card className="glass-dark border-white/10 card-hover">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <i className="fas fa-font mr-3 text-blue-400"></i>
            Типографика
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-sm text-white/80 block mb-2">Шрифт</Label>
            <Select
              value={settings.fontFamily}
              onValueChange={(value) => onSettingsChange({ fontFamily: value })}
            >
              <SelectTrigger className="bg-white/10 border-white/20 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="glass-dark border-white/10">
                <SelectItem value="Inter">
                  <span style={{ fontFamily: 'Inter, sans-serif' }}>Inter</span>
                </SelectItem>
                <SelectItem value="Raleway">
                  <span style={{ fontFamily: 'Raleway, sans-serif' }}>Raleway</span>
                </SelectItem>
                <SelectItem value="Unbounded">
                  <span style={{ fontFamily: 'Unbounded, sans-serif' }}>Unbounded</span>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-3">
            <Checkbox
              checked={settings.usernameTextShadow}
              onCheckedChange={(checked) => onSettingsChange({ usernameTextShadow: !!checked })}
              className="data-[state=checked]:bg-indigo-600"
            />
            <Label className="text-sm text-white/80">Text Shadow для никнейма</Label>
          </div>

          {settings.usernameTextShadow && (
            <div className="space-y-4 pl-6 border-l-2 border-white/20">
              <ColorPicker
                value={settings.textShadowColor}
                onChange={(color) => onSettingsChange({ textShadowColor: color })}
                label="Цвет тени"
              />
              <RangeSlider
                value={settings.textShadowBlur}
                onChange={(value) => onSettingsChange({ textShadowBlur: value })}
                min={0}
                max={20}
                label="Размытие тени"
              />
              <RangeSlider
                value={settings.textShadowOffsetX}
                onChange={(value) => onSettingsChange({ textShadowOffsetX: value })}
                min={-10}
                max={10}
                label="Смещение по X"
              />
              <RangeSlider
                value={settings.textShadowOffsetY}
                onChange={(value) => onSettingsChange({ textShadowOffsetY: value })}
                min={-10}
                max={10}
                label="Смещение по Y"
              />
              <RangeSlider
                value={settings.textShadowOpacity}
                onChange={(value) => onSettingsChange({ textShadowOpacity: value })}
                min={0}
                max={100}
                label="Прозрачность тени"
                unit="%"
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Theme Colors */}
      <Card className="glass-dark border-white/10 card-hover">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <i className="fas fa-palette mr-3 text-indigo-400"></i>
            Основные цвета
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <ColorPicker
            value={settings.themeColor}
            onChange={(color) => onSettingsChange({ themeColor: color })}
            label="Theme Color"
          />
          <ColorPicker
            value={settings.primaryTextColor}
            onChange={(color) => onSettingsChange({ primaryTextColor: color })}
            label="Primary Text"
          />
          <ColorPicker
            value={settings.secondaryTextColor}
            onChange={(color) => onSettingsChange({ secondaryTextColor: color })}
            label="Secondary Text"
          />
        </CardContent>
      </Card>

      {/* Box Settings */}
      <Card className="glass-dark border-white/10 card-hover">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <i className="fas fa-cube mr-3 text-purple-400"></i>
            Настройки карточки
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <RangeSlider
            value={settings.boxWidth}
            onChange={(value) => onSettingsChange({ boxWidth: value })}
            min={300}
            max={500}
            label="Box Width"
          />
          <RangeSlider
            value={settings.boxInnerSpacing}
            onChange={(value) => onSettingsChange({ boxInnerSpacing: value })}
            min={16}
            max={48}
            label="Inner Spacing"
          />
          <ColorPicker
            value={settings.boxColor}
            onChange={(color) => onSettingsChange({ boxColor: color })}
            label="Box Color"
          />
          <RangeSlider
            value={settings.boxOpacity}
            onChange={(value) => onSettingsChange({ boxOpacity: value })}
            min={0}
            max={100}
            label="Box Opacity"
            unit="%"
          />
          <RangeSlider
            value={settings.boxRadius}
            onChange={(value) => onSettingsChange({ boxRadius: value })}
            min={0}
            max={32}
            label="Border Radius"
          />
          <RangeSlider
            value={settings.boxBlur}
            onChange={(value) => onSettingsChange({ boxBlur: value })}
            min={0}
            max={40}
            label="Blur Intensity"
          />
        </CardContent>
      </Card>

      {/* Shadow & Border */}
      <Card className="glass-dark border-white/10 card-hover">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <i className="fas fa-border-style mr-3 text-amber-400"></i>
            Тень и рамка
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <ColorPicker
            value={settings.boxShadowColor}
            onChange={(color) => onSettingsChange({ boxShadowColor: color })}
            label="Shadow Color"
          />
          <RangeSlider
            value={settings.boxShadowOpacity}
            onChange={(value) => onSettingsChange({ boxShadowOpacity: value })}
            min={0}
            max={100}
            label="Shadow Opacity"
            unit="%"
          />
          <RangeSlider
            value={settings.borderWidth}
            onChange={(value) => onSettingsChange({ borderWidth: value })}
            min={0}
            max={5}
            label="Border Width"
          />
          <ColorPicker
            value={settings.borderColor}
            onChange={(color) => onSettingsChange({ borderColor: color })}
            label="Border Color"
          />
          <RangeSlider
            value={settings.borderOpacity}
            onChange={(value) => onSettingsChange({ borderOpacity: value })}
            min={0}
            max={100}
            label="Border Opacity"
            unit="%"
          />
        </CardContent>
      </Card>

      {/* Background Settings */}
      <Card className="glass-dark border-white/10 card-hover">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <i className="fas fa-image mr-3 text-emerald-400"></i>
            Фон карточки
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <ColorPicker
            value={settings.backgroundColor || "#1a1a2e"}
            onChange={(color) => onSettingsChange({ backgroundColor: color })}
            label="Background Color"
          />
          <RangeSlider
            value={settings.backgroundOpacity || 100}
            onChange={(value) => onSettingsChange({ backgroundOpacity: value })}
            min={0}
            max={100}
            label="Background Opacity"
            unit="%"
          />
          <RangeSlider
            value={settings.backgroundBlur || 5}
            onChange={(value) => onSettingsChange({ backgroundBlur: value })}
            min={0}
            max={20}
            label="Размытие фона"
          />
        </CardContent>
      </Card>

      {/* Banner & Display */}
      <Card className="glass-dark border-white/10 card-hover">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <i className="fas fa-image mr-3 text-emerald-400"></i>
            Баннер и отображение
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-3">
            <Checkbox
              checked={settings.showBanner}
              onCheckedChange={(checked) => onSettingsChange({ showBanner: !!checked })}
              className="data-[state=checked]:bg-indigo-600"
            />
            <Label className="text-sm text-white/80">Показать баннер</Label>
          </div>
          <RangeSlider
            value={settings.bannerHeight}
            onChange={(value) => onSettingsChange({ bannerHeight: value })}
            min={100}
            max={300}
            label="Высота баннера"
          />
          <div className="flex items-center space-x-3">
            <Checkbox
              checked={settings.showUserId}
              onCheckedChange={(checked) => onSettingsChange({ showUserId: !!checked })}
              className="data-[state=checked]:bg-indigo-600"
            />
            <Label className="text-sm text-white/80">Показать User ID</Label>
          </div>
          <div className="flex items-center space-x-3">
            <Checkbox
              checked={settings.showViewCount}
              onCheckedChange={(checked) => onSettingsChange({ showViewCount: !!checked })}
              className="data-[state=checked]:bg-indigo-600"
            />
            <Label className="text-sm text-white/80">Показать просмотры</Label>
          </div>
        </CardContent>
      </Card>

      {/* Avatar Settings */}
      <Card className="glass-dark border-white/10 card-hover">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <i className="fas fa-user-circle mr-3 text-pink-400"></i>
            Аватар
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <RangeSlider
            value={settings.avatarRadius}
            onChange={(value) => onSettingsChange({ avatarRadius: value })}
            min={0}
            max={50}
            label="Avatar Radius"
            unit="%"
          />
          <div className="flex items-center space-x-3">
            <Checkbox
              checked={settings.usernameSparkles}
              onCheckedChange={(checked) => onSettingsChange({ usernameSparkles: !!checked })}
              className="data-[state=checked]:bg-indigo-600"
            />
            <Label className="text-sm text-white/80">Username Sparkles</Label>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}