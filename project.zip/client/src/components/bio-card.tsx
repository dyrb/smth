import { hexToRgb } from "@/lib/colors";
import type { User, BioPage, DesignSettings, SocialLink } from "@shared/schema";

interface BioCardProps {
  user?: User;
  bioPage?: BioPage;
  customSettings?: DesignSettings;
  customSocialLinks?: SocialLink[];
  isPreview?: boolean;
  isPublic?: boolean;
}

export default function BioCard({ 
  user, 
  bioPage, 
  customSettings, 
  customSocialLinks,
  isPreview = false,
  isPublic = false
}: BioCardProps) {
  // Use custom settings if provided, otherwise use bioPage settings or defaults
  const settings = customSettings || (bioPage?.customSettings as DesignSettings) || {
    themeColor: "#6366F1",
    primaryTextColor: "#FFFFFF",
    secondaryTextColor: "#CBD5E1",
    boxWidth: 400,
    boxInnerSpacing: 32,
    boxColor: "#1E1B2E",
    boxOpacity: 20,
    boxRadius: 16,
    boxBlur: 20,
    boxShadowColor: "#6366F1",
    boxShadowOpacity: 30,
    borderWidth: 1,
    borderColor: "#FFFFFF",
    borderOpacity: 20,
    borderStyle: "solid",
    usernameSparkles: true,
    avatarRadius: 50,
    bannerHeight: 200,
    showBanner: true,
    showViewCount: true,
    showUserId: true,
    backgroundBlur: 5,
    fontFamily: "Inter",
    usernameTextShadow: false,
    textShadowColor: "#000000",
    textShadowBlur: 4,
    textShadowOffsetX: 2,
    textShadowOffsetY: 2,
    textShadowOpacity: 50,
    backgroundColor: "#1a1a2e",
    backgroundOpacity: 100,
  };

  const socialLinks = customSocialLinks || (bioPage?.socialLinks as SocialLink[]) || [];

  const socialIcons: Record<string, string> = {
    instagram: "fab fa-instagram",
    youtube: "fab fa-youtube",
    telegram: "fab fa-telegram",
    github: "fab fa-github",
    twitter: "fab fa-twitter",
    linkedin: "fab fa-linkedin",
    tiktok: "fab fa-tiktok",
    discord: "fab fa-discord",
  };

  const socialColors: Record<string, string> = {
    instagram: "text-pink-400",
    youtube: "text-red-400",
    telegram: "text-blue-400",
    github: "text-gray-300",
    twitter: "text-blue-300",
    linkedin: "text-blue-500",
    tiktok: "text-gray-300",
    discord: "text-indigo-400",
  };

  // Определяем правильный класс шрифта
  const getFontClass = (fontFamily: string) => {
    switch (fontFamily) {
      case 'Raleway':
        return 'font-raleway';
      case 'Unbounded':
        return 'font-unbounded';
      case 'Inter':
      default:
        return 'font-inter';
    }
  };

  const cardStyle = {
    width: `${settings.boxWidth}px`,
    padding: `${settings.boxInnerSpacing}px`,
    background: `rgba(${hexToRgb(settings.boxColor)}, ${settings.boxOpacity / 100})`,
    borderRadius: `${settings.boxRadius}px`,
    backdropFilter: `blur(${settings.boxBlur}px)`,
    boxShadow: `0 25px 50px rgba(${hexToRgb(settings.boxShadowColor)}, ${settings.boxShadowOpacity / 100})`,
    border: `${settings.borderWidth}px ${settings.borderStyle} rgba(${hexToRgb(settings.borderColor)}, ${settings.borderOpacity / 100})`,
  };

  const avatarStyle = {
    borderRadius: `${settings.avatarRadius}%`,
  };

  const nameStyle = {
    color: settings.primaryTextColor,
    textShadow: settings.usernameTextShadow 
      ? `${settings.textShadowOffsetX}px ${settings.textShadowOffsetY}px ${settings.textShadowBlur}px rgba(${hexToRgb(settings.textShadowColor)}, ${settings.textShadowOpacity / 100})`
      : 'none',
  };

  const bioStyle = {
    color: settings.secondaryTextColor,
  };

  const displayName = user?.username || "demo";
  
  // Handle bio display logic
  let displayBio = "";
  if (isPublic) {
    // In public view, only show bio if user has actually set one
    displayBio = (user?.bio && user.bio.trim() !== "") ? user.bio : "";
  } else {
    // In preview/editor, show placeholder if no bio is set
    displayBio = (user?.bio && user.bio.trim() !== "") ? user.bio : "Enter your description";
  }
  
  const displayAvatar = user?.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=200&h=200&fit=crop&crop=face";
  const displayBanner = user?.banner || "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&w=800&h=400&fit=crop";
  
  // Use user's background image if available, otherwise use default
  const displayBackgroundImage = user?.backgroundImage || "https://images.unsplash.com/photo-1557683316-973673baf926?ixlib=rb-4.0.3&w=1200&h=800&fit=crop";

  const bannerStyle = {
    height: `${settings.bannerHeight}px`,
    background: `url(${displayBanner}) center/cover`,
  };

  // Use the actual user_number from database, fallback to 1 for demo
  const displayUserId = user?.userNumber || 1;

  // Background style with blur effect applied to the image
  const backgroundStyle = {
    backgroundImage: `url(${displayBackgroundImage})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    filter: settings.backgroundBlur ? `blur(${settings.backgroundBlur}px)` : 'none',
  };

  // Background color overlay style
  const backgroundOverlayStyle = {
    backgroundColor: `rgba(${hexToRgb(settings.backgroundColor || "#1a1a2e")}, ${(settings.backgroundOpacity || 100) / 100})`,
  };

  return (
    <div className="relative">
      {/* Background Image with Blur Effect */}
      <div 
        className="absolute inset-0 rounded-3xl"
        style={backgroundStyle}
      ></div>
      
      {/* Background Color Overlay */}
      <div 
        className="absolute inset-0 rounded-3xl"
        style={backgroundOverlayStyle}
      ></div>
      
      {/* Bio Card - Apply font class here */}
      <div
        style={cardStyle}
        className={`relative backdrop-blur-xl transition-all duration-300 overflow-hidden ${getFontClass(settings.fontFamily)}`}
      >
        {/* Banner Section */}
        {settings.showBanner && (
          <div className="relative -m-8 mb-0">
            <div 
              style={bannerStyle}
              className="w-full relative rounded-t-2xl"
            >
              <div className="absolute inset-0 bg-black/20"></div>
              
              {/* User ID and View Count in top right */}
              <div className="absolute top-4 right-4 flex flex-col items-end space-y-2">
                {settings.showUserId && (
                  <div className="glass-morphism px-3 py-1 rounded-lg">
                    <span className="text-white/80 text-xs font-mono">ID: {displayUserId}</span>
                  </div>
                )}
                {settings.showViewCount && (
                  <div className="glass-morphism px-3 py-1 rounded-lg">
                    <span className="text-white/80 text-xs">
                      <i className="fas fa-eye mr-1"></i>
                      {user?.viewCount || 0}
                    </span>
                  </div>
                )}
              </div>
            </div>
            
            {/* Avatar positioned over banner */}
            <div className="absolute -bottom-12 left-1/2 transform -translate-x-1/2">
              <img 
                src={displayAvatar}
                alt="Profile Avatar" 
                style={avatarStyle}
                className="w-24 h-24 object-cover border-4 border-white/30 shadow-xl transition-all duration-300"
              />
            </div>
          </div>
        )}

        {/* Content Section */}
        <div className={`text-center ${settings.showBanner ? 'pt-16 pb-8' : 'py-8'}`}>
          {/* Avatar for non-banner mode */}
          {!settings.showBanner && (
            <div className="mb-6">
              <img 
                src={displayAvatar}
                alt="Profile Avatar" 
                style={avatarStyle}
                className="w-24 h-24 mx-auto object-cover border-4 border-white/20 shadow-lg mb-4 transition-all duration-300"
              />
            </div>
          )}
          
          <div className={`relative inline-block ${settings.usernameSparkles ? 'sparkles-bg' : ''}`}>
            <h1 style={nameStyle} className="text-2xl font-bold mb-2">
              @{displayName}
            </h1>
          </div>
          
          {/* Only show bio if there's content to display */}
          {displayBio && (
            <p style={bioStyle} className="text-sm leading-relaxed whitespace-pre-line mb-6">
              {displayBio}
            </p>
          )}

          {/* Social Icons Row */}
          {socialLinks.length > 0 && (
            <div className="flex justify-center space-x-4 mb-6">
              {socialLinks.filter(link => link.isVisible).slice(0, 8).map((link) => (
                <a 
                  key={link.id}
                  href={isPublic ? link.url : "#"}
                  target={isPublic ? "_blank" : undefined}
                  rel={isPublic ? "noopener noreferrer" : undefined}
                  className={`w-10 h-10 rounded-full bg-white/10 backdrop-blur flex items-center justify-center hover:bg-white/20 transition-all border border-white/20 group ${socialColors[link.platform] || 'text-white'}`}
                  onClick={!isPublic ? (e) => e.preventDefault() : undefined}
                >
                  <i className={`${socialIcons[link.platform] || 'fas fa-link'} text-lg group-hover:scale-110 transition-transform`}></i>
                </a>
              ))}
            </div>
          )}
        </div>
        
        {/* Footer */}
        {isPublic && (
          <div className="mt-8 pt-6 border-t border-white/10 text-center">
            <p className="text-white/40 text-xs">Created with Personal Curator</p>
          </div>
        )}
      </div>
    </div>
  );
}