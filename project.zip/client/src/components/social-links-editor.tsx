import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2, Plus, Edit } from "lucide-react";
import type { SocialLink } from "@shared/schema";

interface SocialLinksEditorProps {
  socialLinks: SocialLink[];
  onSocialLinksChange: (links: SocialLink[]) => void;
}

const platformOptions = [
  { value: "instagram", label: "Instagram", icon: "fab fa-instagram" },
  { value: "youtube", label: "YouTube", icon: "fab fa-youtube" },
  { value: "telegram", label: "Telegram", icon: "fab fa-telegram" },
  { value: "github", label: "GitHub", icon: "fab fa-github" },
  { value: "twitter", label: "Twitter", icon: "fab fa-twitter" },
  { value: "linkedin", label: "LinkedIn", icon: "fab fa-linkedin" },
  { value: "tiktok", label: "TikTok", icon: "fab fa-tiktok" },
  { value: "discord", label: "Discord", icon: "fab fa-discord" },
];

export default function SocialLinksEditor({ socialLinks, onSocialLinksChange }: SocialLinksEditorProps) {
  const [newLink, setNewLink] = useState({
    platform: "",
    title: "",
    url: "",
  });

  const addSocialLink = () => {
    if (!newLink.platform || !newLink.title || !newLink.url) return;

    const platform = platformOptions.find(p => p.value === newLink.platform);
    const link: SocialLink = {
      id: Date.now().toString(),
      platform: newLink.platform,
      title: newLink.title,
      url: newLink.url,
      icon: platform?.icon || "fas fa-link",
      isVisible: true,
    };

    onSocialLinksChange([...socialLinks, link]);
    setNewLink({ platform: "", title: "", url: "" });
  };

  const removeSocialLink = (id: string) => {
    onSocialLinksChange(socialLinks.filter(link => link.id !== id));
  };

  const updateSocialLink = (id: string, updates: Partial<SocialLink>) => {
    onSocialLinksChange(
      socialLinks.map(link => 
        link.id === id ? { ...link, ...updates } : link
      )
    );
  };

  return (
    <Card className="glass-dark border-white/10 card-hover">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <i className="fas fa-link mr-3 text-indigo-400"></i>
          Социальные сети
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add New Link */}
        <div className="space-y-3 p-4 glass-light rounded-xl border border-white/10">
          <Select value={newLink.platform} onValueChange={(value) => {
            setNewLink({ ...newLink, platform: value });
            const platform = platformOptions.find(p => p.value === value);
            if (platform && !newLink.title) {
              setNewLink(prev => ({ ...prev, title: platform.label }));
            }
          }}>
            <SelectTrigger className="bg-white/10 border-white/20 text-white">
              <SelectValue placeholder="Выберите платформу" />
            </SelectTrigger>
            <SelectContent className="glass-dark border-white/10">
              {platformOptions.map((platform) => (
                <SelectItem key={platform.value} value={platform.value}>
                  <div className="flex items-center space-x-2">
                    <i className={platform.icon}></i>
                    <span>{platform.label}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Input
            placeholder="Название ссылки"
            value={newLink.title}
            onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
            className="bg-white/10 border-white/20 text-white placeholder-white/50"
          />
          
          <Input
            type="url"
            placeholder="https://example.com"
            value={newLink.url}
            onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
            className="bg-white/10 border-white/20 text-white placeholder-white/50"
          />
          
          <Button
            onClick={addSocialLink}
            disabled={!newLink.platform || !newLink.title || !newLink.url}
            className="w-full bg-indigo-600 hover:bg-indigo-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Добавить ссылку
          </Button>
        </div>

        {/* Existing Links */}
        <div className="space-y-2">
          {socialLinks.map((link) => {
            const platform = platformOptions.find(p => p.value === link.platform);
            return (
              <div
                key={link.id}
                className="flex items-center justify-between p-3 glass-light rounded-lg border border-white/10 group"
              >
                <div className="flex items-center space-x-3">
                  <i className={platform?.icon || "fas fa-link"} />
                  <div>
                    <div className="text-white text-sm font-medium">{link.title}</div>
                    <div className="text-white/60 text-xs truncate max-w-32">{link.url}</div>
                  </div>
                </div>
                <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 h-8 w-8 p-0"
                    onClick={() => {
                      // In a real app, this would open an edit modal
                      const newTitle = prompt("Новое название:", link.title);
                      if (newTitle) {
                        updateSocialLink(link.id, { title: newTitle });
                      }
                    }}
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-red-400 hover:text-red-300 hover:bg-red-400/10 h-8 w-8 p-0"
                    onClick={() => removeSocialLink(link.id)}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {socialLinks.length === 0 && (
          <div className="text-center py-8 text-white/60">
            <i className="fas fa-link text-2xl mb-4 block"></i>
            <p>Пока нет ссылок</p>
            <p className="text-sm">Добавьте первую ссылку выше</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}