import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/use-auth";
import type { UserWithBanInfo, AdminStats, CreateBanRequest } from "@shared/admin-schema";

export function useAdmin() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Check if current user is admin
  const { data: isAdmin, isLoading: isLoadingAdmin } = useQuery({
    queryKey: ["is-admin", user?.id],
    queryFn: async () => {
      if (!user?.id) return false;
      
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) return false;
      return data?.role === "admin";
    },
    enabled: !!user?.id,
  });

  // Get all users with ban info and invite info
  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: ["admin-users"],
    queryFn: async (): Promise<UserWithBanInfo[]> => {
      const { data: usersData, error: usersError } = await supabase
        .from("users")
        .select(`
          *,
          user_roles!user_roles_user_id_fkey(role),
          user_bans!user_bans_user_id_fkey!left(
            id,
            reason,
            ban_type,
            expires_at,
            is_active,
            banned_by,
            banned_by_user:users!user_bans_banned_by_fkey(username)
          ),
          invited_by_user:users!invited_by(username, user_number)
        `)
        .order("created_at", { ascending: false });

      if (usersError) throw usersError;

      return usersData.map((user: any) => ({
        id: user.id,
        username: user.username,
        email: user.email,
        bio: user.bio,
        avatar: user.avatar,
        banner: user.banner,
        backgroundImage: user.background_image,
        pageUrl: user.page_url,
        isPublic: user.is_public,
        viewCount: user.view_count,
        userNumber: user.user_number,
        createdAt: user.created_at,
        updatedAt: user.updated_at,
        role: user.user_roles?.role || 'user',
        invitedBy: user.invited_by,
        invitedByUsername: user.invited_by_user?.username || null,
        invitedByUserNumber: user.invited_by_user?.user_number || null,
        banInfo: user.user_bans?.length > 0 ? {
          isBanned: user.user_bans[0].is_active && 
            (user.user_bans[0].ban_type === 'permanent' || 
             new Date(user.user_bans[0].expires_at) > new Date()),
          reason: user.user_bans[0].reason,
          banType: user.user_bans[0].ban_type,
          expiresAt: user.user_bans[0].expires_at,
          bannedByUsername: user.user_bans[0].banned_by_user?.username,
        } : null,
      }));
    },
    enabled: !!isAdmin,
  });

  // Get admin stats
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async (): Promise<AdminStats> => {
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
      const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);

      // Total users
      const { count: totalUsers } = await supabase
        .from("users")
        .select("*", { count: "exact", head: true });

      // Active bio pages
      const { count: activeBioPages } = await supabase
        .from("bio_pages")
        .select("*", { count: "exact", head: true })
        .eq("is_active", true);

      // Active bans
      const { count: activeBans } = await supabase
        .from("user_bans")
        .select("*", { count: "exact", head: true })
        .eq("is_active", true);

      // New users today
      const { count: newUsersToday } = await supabase
        .from("users")
        .select("*", { count: "exact", head: true })
        .gte("created_at", today.toISOString());

      // New users this week
      const { count: newUsersThisWeek } = await supabase
        .from("users")
        .select("*", { count: "exact", head: true })
        .gte("created_at", weekAgo.toISOString());

      // New users this month
      const { count: newUsersThisMonth } = await supabase
        .from("users")
        .select("*", { count: "exact", head: true })
        .gte("created_at", monthAgo.toISOString());

      return {
        totalUsers: totalUsers || 0,
        activeBioPages: activeBioPages || 0,
        activeBans: activeBans || 0,
        newUsersToday: newUsersToday || 0,
        newUsersThisWeek: newUsersThisWeek || 0,
        newUsersThisMonth: newUsersThisMonth || 0,
      };
    },
    enabled: !!isAdmin,
  });

  // Ban user mutation
  const banUserMutation = useMutation({
    mutationFn: async (banData: CreateBanRequest) => {
      if (!user?.id) throw new Error("Not authenticated");

      const expiresAt = banData.banType === 'temporary' && banData.duration
        ? new Date(Date.now() + banData.duration * 24 * 60 * 60 * 1000).toISOString()
        : null;

      const { error } = await supabase
        .from("user_bans")
        .insert({
          user_id: banData.userId,
          banned_by: user.id,
          reason: banData.reason,
          ban_type: banData.banType,
          expires_at: expiresAt,
        });

      if (error) throw error;

      // Log admin action
      await supabase
        .from("admin_logs")
        .insert({
          admin_id: user.id,
          action: "ban_user",
          target_user_id: banData.userId,
          details: {
            reason: banData.reason,
            ban_type: banData.banType,
            duration: banData.duration,
          },
        });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
      queryClient.invalidateQueries({ queryKey: ["admin-stats"] });
    },
  });

  // Unban user mutation
  const unbanUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      if (!user?.id) throw new Error("Not authenticated");

      const { error } = await supabase
        .from("user_bans")
        .update({ is_active: false, updated_at: new Date().toISOString() })
        .eq("user_id", userId)
        .eq("is_active", true);

      if (error) throw error;

      // Log admin action
      await supabase
        .from("admin_logs")
        .insert({
          admin_id: user.id,
          action: "unban_user",
          target_user_id: userId,
          details: {},
        });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
      queryClient.invalidateQueries({ queryKey: ["admin-stats"] });
    },
  });

  // Change user role mutation
  const changeUserRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: 'user' | 'admin' }) => {
      if (!user?.id) throw new Error("Not authenticated");

      const { error } = await supabase
        .from("user_roles")
        .upsert({
          user_id: userId,
          role,
          assigned_by: user.id,
          assigned_at: new Date().toISOString(),
        });

      if (error) throw error;

      // Log admin action
      await supabase
        .from("admin_logs")
        .insert({
          admin_id: user.id,
          action: "change_user_role",
          target_user_id: userId,
          details: { new_role: role },
        });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
    },
  });

  return {
    isAdmin: !!isAdmin,
    isLoadingAdmin,
    users,
    isLoadingUsers,
    stats,
    isLoadingStats,
    banUser: banUserMutation.mutate,
    unbanUser: unbanUserMutation.mutate,
    changeUserRole: changeUserRoleMutation.mutate,
    isBanningUser: banUserMutation.isPending,
    isUnbanningUser: unbanUserMutation.isPending,
    isChangingRole: changeUserRoleMutation.isPending,
  };
}