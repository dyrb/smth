import { useState, useCallback, useEffect } from "react";
import type { DesignSettings } from "@shared/schema";

const defaultSettings: DesignSettings = {
  themeColor: "#6366F1",
  primaryTextColor: "#FFFFFF",
  secondaryTextColor: "#CBD5E1",
  boxWidth: 400,
  boxInnerSpacing: 32,
  boxColor: "#1E1B2E",
  boxOpacity: 20,
  boxRadius: 16,
  boxBlur: 20,
  boxShadowColor: "#6366F1",
  boxShadowOpacity: 30,
  borderWidth: 1,
  borderColor: "#FFFFFF",
  borderOpacity: 20,
  borderStyle: "solid",
  usernameSparkles: true,
  avatarRadius: 50,
  bannerHeight: 200,
  showBanner: true,
  showViewCount: true,
  showUserId: true,
  backgroundBlur: 5,
  fontFamily: "Inter",
  usernameTextShadow: false,
  textShadowColor: "#000000",
  textShadowBlur: 4,
  textShadowOffsetX: 2,
  textShadowOffsetY: 2,
  textShadowOpacity: 50,
  backgroundColor: "#1a1a2e",
  backgroundOpacity: 100,
};

export function useBioSettings(initialSettings?: Partial<DesignSettings>) {
  const [settings, setSettings] = useState<DesignSettings>(defaultSettings);
  const [isInitialized, setIsInitialized] = useState(false);

  // Сбрасываем состояние при изменении initialSettings
  useEffect(() => {
    if (initialSettings) {
      console.log("Initializing settings with:", initialSettings);
      const mergedSettings = {
        ...defaultSettings,
        ...initialSettings,
      };
      setSettings(mergedSettings);
      setIsInitialized(true);
    } else {
      // Если нет initialSettings, используем дефолтные
      setSettings(defaultSettings);
      setIsInitialized(true);
    }
  }, [initialSettings]);

  const updateSettings = useCallback((updates: Partial<DesignSettings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
  }, []);

  const resetSettings = useCallback(() => {
    setSettings(defaultSettings);
    setIsInitialized(true);
  }, []);

  const applyTemplate = useCallback((templateName: string) => {
    switch (templateName) {
      case 'minimal':
        updateSettings({
          themeColor: "#6B7280",
          primaryTextColor: "#FFFFFF",
          secondaryTextColor: "#D1D5DB",
          boxColor: "#1F2937",
          boxOpacity: 15,
          usernameSparkles: false,
          backgroundBlur: 3,
          fontFamily: "Inter",
          usernameTextShadow: false,
          backgroundColor: "#111827",
          backgroundOpacity: 90,
        });
        break;
      case 'colorful':
        updateSettings({
          themeColor: "#EC4899",
          primaryTextColor: "#FFFFFF",
          secondaryTextColor: "#FBBF24",
          boxColor: "#BE185D",
          boxOpacity: 25,
          usernameSparkles: true,
          backgroundBlur: 8,
          fontFamily: "Raleway",
          usernameTextShadow: true,
          textShadowColor: "#000000",
          textShadowBlur: 6,
          backgroundColor: "#7C2D12",
          backgroundOpacity: 85,
        });
        break;
      case 'nature':
        updateSettings({
          themeColor: "#10B981",
          primaryTextColor: "#FFFFFF",
          secondaryTextColor: "#A7F3D0",
          boxColor: "#065F46",
          boxOpacity: 20,
          usernameSparkles: false,
          backgroundBlur: 6,
          fontFamily: "Inter",
          usernameTextShadow: false,
          backgroundColor: "#064E3B",
          backgroundOpacity: 95,
        });
        break;
      case 'dark':
        updateSettings({
          themeColor: "#374151",
          primaryTextColor: "#F9FAFB",
          secondaryTextColor: "#9CA3AF",
          boxColor: "#111827",
          boxOpacity: 30,
          usernameSparkles: false,
          backgroundBlur: 4,
          fontFamily: "Unbounded",
          usernameTextShadow: true,
          textShadowColor: "#6366F1",
          textShadowBlur: 8,
          backgroundColor: "#000000",
          backgroundOpacity: 100,
        });
        break;
      default:
        resetSettings();
    }
  }, [updateSettings, resetSettings]);

  return {
    settings,
    updateSettings,
    resetSettings,
    applyTemplate,
    isInitialized,
  };
}