import { useState, useEffect, createContext, useContext } from 'react'
import { User, Session } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase'

interface AuthContextType {
  user: User | null
  session: Session | null
  loading: boolean
  signUp: (email: string, password: string, userData: any, inviteCode?: string) => Promise<any>
  signIn: (email: string, password: string, rememberMe?: boolean) => Promise<any>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Cookie utilities
const setCookie = (name: string, value: string, days: number = 30) => {
  const expires = new Date()
  expires.setTime(expires.getTime() + (days * 24 * 60 * 60 * 1000))
  document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/;secure;samesite=strict`
}

const getCookie = (name: string): string | null => {
  const nameEQ = name + "="
  const ca = document.cookie.split(';')
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i]
    while (c.charAt(0) === ' ') c = c.substring(1, c.length)
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
  }
  return null
}

const deleteCookie = (name: string) => {
  document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;`
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export function useAuthProvider() {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true

    // Function to handle auth state changes
    const handleAuthStateChange = async (event: string, session: Session | null) => {
      if (!mounted) return

      console.log('Auth state changed:', event, session?.user?.email)
      
      setSession(session)
      setUser(session?.user ?? null)
      
      if (session?.access_token) {
        // Save session tokens to cookies if user chose to be remembered
        const rememberMe = getCookie('rememberMe') === 'true'
        if (rememberMe) {
          setCookie('supabase_access_token', session.access_token, 30)
          setCookie('supabase_refresh_token', session.refresh_token || '', 30)
          setCookie('user_email', session.user.email || '', 30)
        }
      } else {
        // Clear cookies on sign out
        deleteCookie('supabase_access_token')
        deleteCookie('supabase_refresh_token')
        deleteCookie('user_email')
        deleteCookie('rememberMe')
      }
      
      setLoading(false)
    }

    // Initialize auth state
    const initializeAuth = async () => {
      try {
        // First, try to get current session
        const { data: { session: currentSession }, error } = await supabase.auth.getSession()
        
        if (currentSession) {
          console.log('Found existing session')
          handleAuthStateChange('INITIAL_SESSION', currentSession)
          return
        }

        // If no current session, try to restore from cookies
        const savedAccessToken = getCookie('supabase_access_token')
        const savedRefreshToken = getCookie('supabase_refresh_token')
        const rememberMe = getCookie('rememberMe') === 'true'

        if (savedRefreshToken && rememberMe) {
          console.log('Attempting to restore session from cookies')
          
          try {
            const { data, error } = await supabase.auth.setSession({
              access_token: savedAccessToken || '',
              refresh_token: savedRefreshToken
            })

            if (error) {
              console.error('Failed to restore session:', error.message)
              // Clear invalid cookies
              deleteCookie('supabase_access_token')
              deleteCookie('supabase_refresh_token')
              deleteCookie('user_email')
              deleteCookie('rememberMe')
              handleAuthStateChange('SIGNED_OUT', null)
            } else if (data.session) {
              console.log('Successfully restored session from cookies')
              handleAuthStateChange('TOKEN_REFRESHED', data.session)
            } else {
              handleAuthStateChange('SIGNED_OUT', null)
            }
          } catch (restoreError) {
            console.error('Error restoring session:', restoreError)
            // Clear cookies on error
            deleteCookie('supabase_access_token')
            deleteCookie('supabase_refresh_token')
            deleteCookie('user_email')
            deleteCookie('rememberMe')
            handleAuthStateChange('SIGNED_OUT', null)
          }
        } else {
          console.log('No saved session found')
          handleAuthStateChange('SIGNED_OUT', null)
        }
      } catch (error) {
        console.error('Error initializing auth:', error)
        setLoading(false)
      }
    }

    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(handleAuthStateChange)

    // Initialize auth
    initializeAuth()

    return () => {
      mounted = false
      subscription.unsubscribe()
    }
  }, [])

  const signUp = async (email: string, password: string, userData: any, inviteCode?: string) => {
    // Validate invite code if provided
    if (inviteCode) {
      const { data: isValid, error: validateError } = await supabase.rpc('is_invite_valid', { 
        invite_code: inviteCode 
      });
      
      if (validateError || !isValid) {
        throw new Error('Недействительный или истекший инвайт-код');
      }
    } else {
      // Check if registration requires invite
      throw new Error('Для регистрации требуется инвайт-код');
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    })

    if (error) throw error

    if (data.user) {
      // Create user profile
      const { error: profileError } = await supabase
        .from('users')
        .insert({
          id: data.user.id,
          email: userData.email,
          username: userData.username,
          page_url: userData.username.toLowerCase(),
          bio: userData.bio || '',
          avatar: userData.avatar || '',
          banner: userData.banner || '',
          background_image: userData.backgroundImage || '',
        })

      if (profileError) throw profileError

      // Create default user role
      await supabase
        .from('user_roles')
        .insert({
          user_id: data.user.id,
          role: 'user',
        })

      // Use invite code if provided
      if (inviteCode) {
        const { error: useInviteError } = await supabase.rpc('use_invite_code', {
          invite_code: inviteCode,
          user_id: data.user.id
        });
        
        if (useInviteError) {
          console.error('Failed to use invite code:', useInviteError);
          // Don't throw error here as user is already created
        }
      }

      // Auto-remember new users for 30 days
      setCookie('rememberMe', 'true', 30)
    }

    return data
  }

  const signIn = async (email: string, password: string, rememberMe: boolean = false) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) throw error

    // Save remember preference
    if (rememberMe) {
      setCookie('rememberMe', 'true', 30)
    } else {
      setCookie('rememberMe', 'false', 1) // Short-lived session
    }

    return data
  }

  const signOut = async () => {
    // Clear all auth-related cookies
    deleteCookie('supabase_access_token')
    deleteCookie('supabase_refresh_token')
    deleteCookie('user_email')
    deleteCookie('rememberMe')

    const { error } = await supabase.auth.signOut()
    if (error) throw error
  }

  return {
    user,
    session,
    loading,
    signUp,
    signIn,
    signOut,
  }
}

export { AuthContext }