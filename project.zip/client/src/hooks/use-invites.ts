import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/use-auth";
import type { InviteWithUserInfo, InviteStats } from "@shared/invite-schema";

export function useInvites() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Get user's invites (created by them)
  const { data: userInvites, isLoading: isLoadingUserInvites } = useQuery({
    queryKey: ["user-invites", user?.id],
    queryFn: async (): Promise<InviteWithUserInfo[]> => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from("invites")
        .select(`
          *,
          created_by_user:users!invites_created_by_fkey(username, avatar),
          used_by_user:users!invites_used_by_fkey(username, avatar)
        `)
        .eq("created_by", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;

      return data.map((invite: any) => ({
        id: invite.id,
        code: invite.code,
        createdBy: invite.created_by,
        usedBy: invite.used_by,
        expiresAt: invite.expires_at,
        isUsed: invite.is_used,
        createdAt: invite.created_at,
        usedAt: invite.used_at,
        createdByUser: invite.created_by_user,
        usedByUser: invite.used_by_user,
      }));
    },
    enabled: !!user?.id,
  });

  // Get invite stats for user
  const { data: inviteStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["invite-stats", user?.id],
    queryFn: async (): Promise<InviteStats> => {
      if (!user?.id) return { totalInvites: 0, usedInvites: 0, expiredInvites: 0, activeInvites: 0 };

      const { data: allInvites, error } = await supabase
        .from("invites")
        .select("is_used, expires_at")
        .eq("created_by", user.id);

      if (error) throw error;

      const now = new Date();
      const totalInvites = allInvites.length;
      const usedInvites = allInvites.filter(invite => invite.is_used).length;
      const expiredInvites = allInvites.filter(invite => 
        !invite.is_used && new Date(invite.expires_at) <= now
      ).length;
      const activeInvites = allInvites.filter(invite => 
        !invite.is_used && new Date(invite.expires_at) > now
      ).length;

      return {
        totalInvites,
        usedInvites,
        expiredInvites,
        activeInvites,
      };
    },
    enabled: !!user?.id,
  });

  // Validate invite code
  const validateInviteMutation = useMutation({
    mutationFn: async (code: string) => {
      const { data, error } = await supabase.rpc('is_invite_valid', { invite_code: code });
      if (error) throw error;
      return data;
    },
  });

  // Give invite to user (admin only)
  const giveInviteToUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const { data, error } = await supabase.rpc('generate_invite_code');
      if (error) throw error;
      
      const inviteCode = data;
      
      const { error: insertError } = await supabase
        .from("invites")
        .insert({
          code: inviteCode,
          created_by: userId,
        });
      
      if (insertError) throw insertError;
      return inviteCode;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-invites"] });
      queryClient.invalidateQueries({ queryKey: ["invite-stats"] });
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
    },
  });

  // Create invite wave (admin only)
  const createInviteWaveMutation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.rpc('create_invite_wave');
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-invites"] });
      queryClient.invalidateQueries({ queryKey: ["invite-stats"] });
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
    },
  });

  // Purge user invites (admin only)
  const purgeUserInvitesMutation = useMutation({
    mutationFn: async (userId: string) => {
      const { data, error } = await supabase.rpc('purge_user_invites', { target_user_id: userId });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-invites"] });
      queryClient.invalidateQueries({ queryKey: ["invite-stats"] });
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
    },
  });

  return {
    userInvites,
    isLoadingUserInvites,
    inviteStats,
    isLoadingStats,
    validateInvite: validateInviteMutation.mutate,
    isValidatingInvite: validateInviteMutation.isPending,
    giveInviteToUser: giveInviteToUserMutation.mutate,
    isGivingInvite: giveInviteToUserMutation.isPending,
    createInviteWave: createInviteWaveMutation.mutate,
    isCreatingInviteWave: createInviteWaveMutation.isPending,
    purgeUserInvites: purgeUserInvitesMutation.mutate,
    isPurgingInvites: purgeUserInvitesMutation.isPending,
  };
}