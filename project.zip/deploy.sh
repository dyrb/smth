#!/bin/bash

# Personal Curator Deployment Script for Ubuntu 22.04
# Domain: specia.lol

set -e

echo "🚀 Starting Personal Curator deployment..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_error "This script should not be run as root"
   exit 1
fi

# Update system
print_status "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
print_status "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 globally
print_status "Installing PM2..."
sudo npm install -g pm2

# Install Nginx
print_status "Installing Nginx..."
sudo apt install -y nginx

# Install Certbot for SSL
print_status "Installing Certbot..."
sudo apt install -y certbot python3-certbot-nginx

# Create application directory
APP_DIR="/var/www/personal-curator"
print_status "Creating application directory: $APP_DIR"
sudo mkdir -p $APP_DIR
sudo chown -R $USER:$USER $APP_DIR

# Clone or copy application files
print_status "Setting up application files..."
# If you're deploying from a git repository:
# git clone https://github.com/yourusername/personal-curator.git $APP_DIR
# cd $APP_DIR

# For now, assuming files are already in current directory
cp -r . $APP_DIR/
cd $APP_DIR

# Create logs directory
mkdir -p logs

# Install dependencies
print_status "Installing dependencies..."
npm ci --only=production

# Build the application
print_status "Building application..."
npm run build

# Setup environment variables
print_status "Setting up environment variables..."
if [ ! -f .env ]; then
    cp .env.production .env
    print_warning "Please edit .env file with your actual Supabase credentials"
    print_warning "Update DATABASE_URL with your actual password"
fi

# Setup Nginx configuration
print_status "Configuring Nginx..."
sudo cp nginx.conf /etc/nginx/sites-available/specia.lol
sudo ln -sf /etc/nginx/sites-available/specia.lol /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
sudo nginx -t

# Setup SSL certificate
print_status "Setting up SSL certificate..."
sudo certbot --nginx -d specia.lol -d www.specia.lol --non-interactive --agree-tos --email admin@specia.lol

# Setup PM2
print_status "Setting up PM2..."
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup

# Setup firewall
print_status "Configuring firewall..."
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
sudo ufw --force enable

# Start services
print_status "Starting services..."
sudo systemctl enable nginx
sudo systemctl restart nginx

print_status "✅ Deployment completed successfully!"
print_status "🌐 Your application should be available at: https://specia.lol"
print_status ""
print_status "📋 Next steps:"
print_status "1. Edit .env file with your actual Supabase credentials"
print_status "2. Update DATABASE_URL with your actual password"
print_status "3. Restart the application: pm2 restart personal-curator"
print_status ""
print_status "🔧 Useful commands:"
print_status "- Check application status: pm2 status"
print_status "- View logs: pm2 logs personal-curator"
print_status "- Restart application: pm2 restart personal-curator"
print_status "- Check Nginx status: sudo systemctl status nginx"
print_status "- Renew SSL certificate: sudo certbot renew"