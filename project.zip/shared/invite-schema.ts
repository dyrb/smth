import { z } from "zod";

// Invite schema
export const inviteSchema = z.object({
  id: z.string(),
  code: z.string(),
  createdBy: z.string(),
  usedBy: z.string().nullable(),
  expiresAt: z.string(),
  isUsed: z.boolean(),
  createdAt: z.string(),
  usedAt: z.string().nullable(),
});

// Invite with user info schema
export const inviteWithUserInfoSchema = z.object({
  id: z.string(),
  code: z.string(),
  createdBy: z.string(),
  usedBy: z.string().nullable(),
  expiresAt: z.string(),
  isUsed: z.boolean(),
  createdAt: z.string(),
  usedAt: z.string().nullable(),
  createdByUser: z.object({
    username: z.string(),
    avatar: z.string().nullable(),
  }).nullable(),
  usedByUser: z.object({
    username: z.string(),
    avatar: z.string().nullable(),
  }).nullable(),
});

// Create invite request schema
export const createInviteSchema = z.object({
  userId: z.string(),
});

// Use invite request schema
export const useInviteSchema = z.object({
  code: z.string().min(1, "Invite code is required"),
  userId: z.string(),
});

// Invite validation schema
export const validateInviteSchema = z.object({
  code: z.string().min(1, "Invite code is required"),
});

// Invite stats schema
export const inviteStatsSchema = z.object({
  totalInvites: z.number(),
  usedInvites: z.number(),
  expiredInvites: z.number(),
  activeInvites: z.number(),
});

export type Invite = z.infer<typeof inviteSchema>;
export type InviteWithUserInfo = z.infer<typeof inviteWithUserInfoSchema>;
export type CreateInviteRequest = z.infer<typeof createInviteSchema>;
export type UseInviteRequest = z.infer<typeof useInviteSchema>;
export type ValidateInviteRequest = z.infer<typeof validateInviteSchema>;
export type InviteStats = z.infer<typeof inviteStatsSchema>;