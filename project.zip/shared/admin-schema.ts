import { z } from "zod";

// User role schema
export const userRoleSchema = z.object({
  id: z.string(),
  userId: z.string(),
  role: z.enum(['user', 'admin']),
  assignedBy: z.string().nullable(),
  assignedAt: z.string(),
});

// User ban schema
export const userBanSchema = z.object({
  id: z.string(),
  userId: z.string(),
  bannedBy: z.string(),
  reason: z.string(),
  banType: z.enum(['temporary', 'permanent']),
  expiresAt: z.string().nullable(),
  isActive: z.boolean(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

// Admin log schema
export const adminLogSchema = z.object({
  id: z.string(),
  adminId: z.string(),
  action: z.string(),
  targetUserId: z.string().nullable(),
  details: z.record(z.any()),
  ipAddress: z.string().nullable(),
  userAgent: z.string().nullable(),
  createdAt: z.string(),
});

// Create ban request schema
export const createBanSchema = z.object({
  userId: z.string(),
  reason: z.string().min(1, "Reason is required"),
  banType: z.enum(['temporary', 'permanent']),
  duration: z.number().optional(), // in days for temporary bans
});

// Admin stats schema
export const adminStatsSchema = z.object({
  totalUsers: z.number(),
  activeBioPages: z.number(),
  activeBans: z.number(),
  newUsersToday: z.number(),
  newUsersThisWeek: z.number(),
  newUsersThisMonth: z.number(),
});

// User with ban info schema
export const userWithBanInfoSchema = z.object({
  id: z.string(),
  username: z.string(),
  email: z.string(),
  bio: z.string().nullable(),
  avatar: z.string().nullable(),
  banner: z.string().nullable(),
  backgroundImage: z.string().nullable(),
  pageUrl: z.string(),
  isPublic: z.boolean(),
  viewCount: z.number(),
  userNumber: z.number().nullable(),
  createdAt: z.string(),
  updatedAt: z.string(),
  role: z.enum(['user', 'admin']).nullable(),
  invitedBy: z.string().nullable(),
  invitedByUsername: z.string().nullable(),
  invitedByUserNumber: z.number().nullable(),
  banInfo: z.object({
    isBanned: z.boolean(),
    reason: z.string().nullable(),
    banType: z.string().nullable(),
    expiresAt: z.string().nullable(),
    bannedByUsername: z.string().nullable(),
  }).nullable(),
});

export type UserRole = z.infer<typeof userRoleSchema>;
export type UserBan = z.infer<typeof userBanSchema>;
export type AdminLog = z.infer<typeof adminLogSchema>;
export type CreateBanRequest = z.infer<typeof createBanSchema>;
export type AdminStats = z.infer<typeof adminStatsSchema>;
export type UserWithBanInfo = z.infer<typeof userWithBanInfoSchema>;