import { pgTable, text, integer, boolean, jsonb, uuid, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { sql } from "drizzle-orm";
import { z } from "zod";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  bio: text("bio").default(""),
  avatar: text("avatar").default(""),
  banner: text("banner").default(""),
  backgroundImage: text("background_image").default(""),
  pageUrl: text("page_url").notNull().unique(),
  isPublic: boolean("is_public").default(true),
  viewCount: integer("view_count").default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
  userNumber: integer("user_number"),
  invitedBy: uuid("invited_by").references(() => users.id),
});

export const bioPages = pgTable("bio_pages", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description").default(""),
  customSettings: jsonb("custom_settings").notNull().default("{}"),
  socialLinks: jsonb("social_links").notNull().default("[]"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const userRoles = pgTable("user_roles", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }).unique(),
  role: text("role").notNull().default("user"),
  assignedBy: uuid("assigned_by").references(() => users.id),
  assignedAt: timestamp("assigned_at", { withTimezone: true }).defaultNow(),
});

export const userBans = pgTable("user_bans", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  bannedBy: uuid("banned_by").notNull().references(() => users.id),
  reason: text("reason").notNull(),
  banType: text("ban_type").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const adminLogs = pgTable("admin_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  adminId: uuid("admin_id").notNull().references(() => users.id),
  action: text("action").notNull(),
  targetUserId: uuid("target_user_id").references(() => users.id),
  details: jsonb("details").default("{}"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const invites = pgTable("invites", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: text("code").notNull().unique(),
  createdBy: uuid("created_by").notNull().references(() => users.id, { onDelete: "cascade" }),
  usedBy: uuid("used_by").references(() => users.id),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull().default(sql`now() + interval '1 year'`),
  isUsed: boolean("is_used").default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  usedAt: timestamp("used_at", { withTimezone: true }),
});

export const socialLinkSchema = z.object({
  id: z.string(),
  platform: z.string(),
  url: z.string().url(),
  title: z.string(),
  icon: z.string(),
  isVisible: z.boolean().default(true),
});

export const designSettingsSchema = z.object({
  themeColor: z.string().default("#6366F1"),
  primaryTextColor: z.string().default("#FFFFFF"),
  secondaryTextColor: z.string().default("#CBD5E1"),
  boxWidth: z.number().default(400),
  boxInnerSpacing: z.number().default(32),
  boxColor: z.string().default("#1E1B2E"),
  boxOpacity: z.number().default(20),
  boxRadius: z.number().default(16),
  boxBlur: z.number().default(20),
  boxShadowColor: z.string().default("#6366F1"),
  boxShadowOpacity: z.number().default(30),
  borderWidth: z.number().default(1),
  borderColor: z.string().default("#FFFFFF"),
  borderOpacity: z.number().default(20),
  borderStyle: z.string().default("solid"),
  usernameSparkles: z.boolean().default(true),
  avatarRadius: z.number().default(50),
  bannerHeight: z.number().default(200),
  showBanner: z.boolean().default(true),
  showViewCount: z.boolean().default(true),
  showUserId: z.boolean().default(true),
  backgroundBlur: z.number().default(5),
  // New font and text shadow settings
  fontFamily: z.string().default("Inter"),
  usernameTextShadow: z.boolean().default(false),
  textShadowColor: z.string().default("#000000"),
  textShadowBlur: z.number().default(4),
  textShadowOffsetX: z.number().default(2),
  textShadowOffsetY: z.number().default(2),
  textShadowOpacity: z.number().default(50),
  // New background settings
  backgroundColor: z.string().default("#1a1a2e"),
  backgroundOpacity: z.number().default(100),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBioPageSchema = createInsertSchema(bioPages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  socialLinks: z.array(socialLinkSchema),
  customSettings: designSettingsSchema,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertBioPage = z.infer<typeof insertBioPageSchema>;
export type BioPage = typeof bioPages.$inferSelect;
export type SocialLink = z.infer<typeof socialLinkSchema>;
export type DesignSettings = z.infer<typeof designSettingsSchema>;
export type UserRole = typeof userRoles.$inferSelect;
export type UserBan = typeof userBans.$inferSelect;
export type AdminLog = typeof adminLogs.$inferSelect;
export type Invite = typeof invites.$inferSelect;