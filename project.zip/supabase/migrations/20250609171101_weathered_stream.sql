/*
  # Admin System Implementation

  1. New Tables
    - `user_roles` - User role management
    - `user_bans` - Ban system
    - `admin_logs` - Admin action logging

  2. Security
    - Enable RLS on all admin tables
    - Add policies for admin access only
    - Update existing policies for ban checks

  3. Functions
    - Check if user is banned
    - Check if user is admin
    - Log admin actions
*/

-- Create user roles table
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  assigned_by uuid REFERENCES users(id),
  assigned_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Create user bans table
CREATE TABLE IF NOT EXISTS user_bans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  banned_by uuid NOT NULL REFERENCES users(id),
  reason text NOT NULL,
  ban_type text NOT NULL CHECK (ban_type IN ('temporary', 'permanent')),
  expires_at timestamptz,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create admin logs table
CREATE TABLE IF NOT EXISTS admin_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL REFERENCES users(id),
  action text NOT NULL,
  target_user_id uuid REFERENCES users(id),
  details jsonb DEFAULT '{}',
  ip_address inet,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all admin tables
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_bans ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_logs ENABLE ROW LEVEL SECURITY;

-- Function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(user_uuid uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = user_uuid AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check if user is banned
CREATE OR REPLACE FUNCTION is_user_banned(user_uuid uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_bans 
    WHERE user_id = user_uuid 
    AND is_active = true 
    AND (ban_type = 'permanent' OR expires_at > now())
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get user ban info
CREATE OR REPLACE FUNCTION get_user_ban_info(user_uuid uuid)
RETURNS TABLE (
  is_banned boolean,
  reason text,
  ban_type text,
  expires_at timestamptz,
  banned_by_username text
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    CASE WHEN ub.id IS NOT NULL THEN true ELSE false END as is_banned,
    ub.reason,
    ub.ban_type,
    ub.expires_at,
    u.username as banned_by_username
  FROM user_bans ub
  LEFT JOIN users u ON ub.banned_by = u.id
  WHERE ub.user_id = user_uuid 
  AND ub.is_active = true 
  AND (ub.ban_type = 'permanent' OR ub.expires_at > now())
  ORDER BY ub.created_at DESC
  LIMIT 1;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RLS Policies for user_roles
CREATE POLICY "Admins can manage all roles"
  ON user_roles
  FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Users can read their own role"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- RLS Policies for user_bans
CREATE POLICY "Admins can manage all bans"
  ON user_bans
  FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()));

-- RLS Policies for admin_logs
CREATE POLICY "Admins can read all logs"
  ON admin_logs
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can insert logs"
  ON admin_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin(auth.uid()));

-- Update existing policies to check for bans
DROP POLICY IF EXISTS "Users can read own data" ON users;
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id AND NOT is_user_banned(auth.uid()));

DROP POLICY IF EXISTS "Users can update own data" ON users;
CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id AND NOT is_user_banned(auth.uid()));

DROP POLICY IF EXISTS "Users can insert their own profile" ON users;
CREATE POLICY "Users can insert their own profile"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id AND NOT is_user_banned(auth.uid()));

-- Add admin policies for users table
CREATE POLICY "Admins can read all users"
  ON users
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can update all users"
  ON users
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));

-- Update bio_pages policies to check for bans
DROP POLICY IF EXISTS "Users can read own bio pages" ON bio_pages;
CREATE POLICY "Users can read own bio pages"
  ON bio_pages
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() AND NOT is_user_banned(auth.uid()));

DROP POLICY IF EXISTS "Users can insert own bio pages" ON bio_pages;
CREATE POLICY "Users can insert own bio pages"
  ON bio_pages
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid() AND NOT is_user_banned(auth.uid()));

DROP POLICY IF EXISTS "Users can update own bio pages" ON bio_pages;
CREATE POLICY "Users can update own bio pages"
  ON bio_pages
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid() AND NOT is_user_banned(auth.uid()));

DROP POLICY IF EXISTS "Users can delete own bio pages" ON bio_pages;
CREATE POLICY "Users can delete own bio pages"
  ON bio_pages
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid() AND NOT is_user_banned(auth.uid()));

-- Add admin policies for bio_pages
CREATE POLICY "Admins can read all bio pages"
  ON bio_pages
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can update all bio pages"
  ON bio_pages
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can delete all bio pages"
  ON bio_pages
  FOR DELETE
  TO authenticated
  USING (is_admin(auth.uid()));

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role ON user_roles(role);
CREATE INDEX IF NOT EXISTS idx_user_bans_user_id ON user_bans(user_id);
CREATE INDEX IF NOT EXISTS idx_user_bans_active ON user_bans(is_active);
CREATE INDEX IF NOT EXISTS idx_user_bans_expires ON user_bans(expires_at);
CREATE INDEX IF NOT EXISTS idx_admin_logs_admin_id ON admin_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_logs_created_at ON admin_logs(created_at);

-- Insert default admin role (you'll need to update this with your actual admin user ID)
-- This is just a placeholder - replace with actual admin user ID after registration
-- INSERT INTO user_roles (user_id, role, assigned_by) 
-- VALUES ('your-admin-user-id-here', 'admin', 'your-admin-user-id-here');