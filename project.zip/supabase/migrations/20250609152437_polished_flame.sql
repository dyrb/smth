/*
  # Create bio_pages table

  1. New Tables
    - `bio_pages`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `title` (text)
      - `description` (text)
      - `custom_settings` (jsonb)
      - `social_links` (jsonb)
      - `is_active` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
  2. Security
    - Enable RLS on `bio_pages` table
    - Add policies for authenticated users to manage their own bio pages
    - Add policy for public access to active bio pages
*/

CREATE TABLE IF NOT EXISTS bio_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  custom_settings jsonb NOT NULL DEFAULT '{}',
  social_links jsonb NOT NULL DEFAULT '[]',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE bio_pages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own bio pages"
  ON bio_pages
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own bio pages"
  ON bio_pages
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own bio pages"
  ON bio_pages
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can delete own bio pages"
  ON bio_pages
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Active bio pages are viewable by everyone"
  ON bio_pages
  FOR SELECT
  TO anon
  USING (is_active = true);