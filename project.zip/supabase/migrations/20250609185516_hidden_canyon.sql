/*
  # Fix user_roles RLS policy for registration

  1. Changes
    - Update RLS policies to allow users to insert their own default role
    - Maintain admin privileges for role management
    - Allow users to read their own role

  2. Security
    - Users can only insert 'user' role for themselves
    - Only admins can assign 'admin' roles
    - Users can read their own role
    - Admins can manage all roles
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can manage all roles" ON user_roles;
DROP POLICY IF EXISTS "Users can read their own role" ON user_roles;

-- Allow users to read their own role
CREATE POLICY "Users can read their own role"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Allow users to insert their own default 'user' role
CREATE POLICY "Users can insert their own user role"
  ON user_roles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    user_id = auth.uid() 
    AND role = 'user'
  );

-- Allow admins to insert any role for any user
CREATE POLICY "Admins can insert any role"
  ON user_roles
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin(auth.uid()));

-- Allow admins to update any role
CREATE POLICY "Admins can update all roles"
  ON user_roles
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));

-- Allow admins to delete any role
CREATE POLICY "Admins can delete all roles"
  ON user_roles
  FOR DELETE
  TO authenticated
  USING (is_admin(auth.uid()));

-- Allow admins to read all roles
CREATE POLICY "Admins can read all roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (is_admin(auth.uid()));