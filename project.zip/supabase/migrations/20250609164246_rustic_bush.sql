/*
  # Remove name field from users table

  1. Changes
    - Remove `name` column from users table
    - Update any references to use username instead

  2. Security
    - Maintain existing RLS policies
*/

-- Remove the name column from users table
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'name'
  ) THEN
    ALTER TABLE users DROP COLUMN name;
  END IF;
END $$;