/*
  # Add user numbering system

  1. Changes
    - Add `user_number` column to users table
    - Create sequence for auto-incrementing user numbers
    - Add trigger to automatically assign user numbers
    - Update existing users with sequential numbers

  2. Security
    - Maintain existing RLS policies
*/

-- Add user_number column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'user_number'
  ) THEN
    ALTER TABLE users ADD COLUMN user_number integer;
  END IF;
END $$;

-- Create sequence for user numbers
CREATE SEQUENCE IF NOT EXISTS user_number_seq START 1;

-- Create function to assign user number
CREATE OR REPLACE FUNCTION assign_user_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.user_number IS NULL THEN
    NEW.user_number := nextval('user_number_seq');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically assign user numbers on insert
DROP TRIGGER IF EXISTS assign_user_number_trigger ON users;
CREATE TRIGGER assign_user_number_trigger
  BEFORE INSERT ON users
  FOR EACH ROW
  EXECUTE FUNCTION assign_user_number();

-- Update existing users with sequential numbers (if any exist)
DO $$
DECLARE
  user_record RECORD;
  counter INTEGER := 1;
BEGIN
  FOR user_record IN 
    SELECT id FROM users WHERE user_number IS NULL ORDER BY created_at
  LOOP
    UPDATE users SET user_number = counter WHERE id = user_record.id;
    counter := counter + 1;
  END LOOP;
  
  -- Set sequence to continue from the last assigned number
  IF counter > 1 THEN
    PERFORM setval('user_number_seq', counter - 1);
  END IF;
END $$;