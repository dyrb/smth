/*
  # Fix invited_by foreign key relationship

  1. Changes
    - Drop existing foreign key constraint if it exists
    - Add proper foreign key constraint with correct name
    - Ensure the relationship works for Supabase queries

  2. Security
    - Maintain existing RLS policies
*/

-- Drop existing foreign key constraint if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'users_invited_by_fkey' 
    AND table_name = 'users'
  ) THEN
    ALTER TABLE users DROP CONSTRAINT users_invited_by_fkey;
  END IF;
END $$;

-- Add the foreign key constraint with the correct name that matches the column
ALTER TABLE users 
ADD CONSTRAINT users_invited_by_fkey 
FOREIGN KEY (invited_by) REFERENCES users(id);

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_users_invited_by ON users(invited_by);