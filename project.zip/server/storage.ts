import { users, bioPages, type User, type InsertUser, type BioPage, type InsertBioPage } from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByPageUrl(pageUrl: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;

  // Bio Pages
  getBioPage(id: number): Promise<BioPage | undefined>;
  getBioPageByUserId(userId: number): Promise<BioPage | undefined>;
  getBioPageByUrl(pageUrl: string): Promise<BioPage | undefined>;
  createBioPage(bioPage: InsertBioPage): Promise<BioPage>;
  updateBioPage(id: number, bioPage: Partial<InsertBioPage>): Promise<BioPage | undefined>;
  deleteBioPage(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private bioPages: Map<number, BioPage>;
  private currentUserId: number;
  private currentBioPageId: number;

  constructor() {
    this.users = new Map();
    this.bioPages = new Map();
    this.currentUserId = 1;
    this.currentBioPageId = 1;
    
    // Create a demo user for testing
    this.createDemoData();
  }

  private async createDemoData() {
    // Create demo user
    const demoUser = await this.createUser({
      username: "demo",
      email: "demo@example.com", 
      name: "Александр Иванов",
      bio: "Full-stack разработчик и дизайнер. Создаю современные веб-приложения и люблю экспериментировать с новыми технологиями.",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=200&h=200&fit=crop&crop=face",
      banner: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&w=800&h=400&fit=crop",
      backgroundImage: "https://images.unsplash.com/photo-1557683316-973673baf926?ixlib=rb-4.0.3&w=1200&h=800&fit=crop",
      pageUrl: "demo",
      isPublic: true,
      viewCount: 0,
    });

    // Create demo bio page
    await this.createBioPage({
      userId: demoUser.id,
      title: "Александр Иванов",
      description: "Мой персональный профиль",
      customSettings: {
        themeColor: "#6366F1",
        primaryTextColor: "#FFFFFF",
        secondaryTextColor: "#CBD5E1",
        boxWidth: 400,
        boxInnerSpacing: 32,
        boxColor: "#1E1B2E",
        boxOpacity: 20,
        boxRadius: 16,
        boxBlur: 20,
        boxShadowColor: "#6366F1",
        boxShadowOpacity: 30,
        borderWidth: 1,
        borderColor: "#FFFFFF",
        borderOpacity: 20,
        borderStyle: "solid",
        usernameSparkles: true,
        avatarRadius: 50,
        bannerHeight: 200,
        showBanner: true,
        showViewCount: true,
        showUserId: true,
        backgroundBlur: 5,
      },
      socialLinks: [
        { id: "1", platform: "instagram", url: "https://instagram.com", title: "Instagram", icon: "fab fa-instagram", isVisible: true },
        { id: "2", platform: "youtube", url: "https://youtube.com", title: "YouTube", icon: "fab fa-youtube", isVisible: true },
        { id: "3", platform: "github", url: "https://github.com", title: "GitHub", icon: "fab fa-github", isVisible: true },
        { id: "4", platform: "telegram", url: "https://t.me", title: "Telegram", icon: "fab fa-telegram", isVisible: true },
      ],
      isActive: true,
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByPageUrl(pageUrl: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.pageUrl === pageUrl,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      bio: insertUser.bio || "",
      avatar: insertUser.avatar || "",
      banner: insertUser.banner || "",
      backgroundImage: insertUser.backgroundImage || "",
      isPublic: insertUser.isPublic ?? true,
      viewCount: insertUser.viewCount ?? 0,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updateUser: Partial<InsertUser>): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;

    const updatedUser: User = { ...existingUser, ...updateUser };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Bio Pages
  async getBioPage(id: number): Promise<BioPage | undefined> {
    return this.bioPages.get(id);
  }

  async getBioPageByUserId(userId: number): Promise<BioPage | undefined> {
    return Array.from(this.bioPages.values()).find(
      (page) => page.userId === userId && page.isActive,
    );
  }

  async getBioPageByUrl(pageUrl: string): Promise<BioPage | undefined> {
    const user = await this.getUserByPageUrl(pageUrl);
    if (!user) return undefined;
    return this.getBioPageByUserId(user.id);
  }

  async createBioPage(insertBioPage: InsertBioPage): Promise<BioPage> {
    const id = this.currentBioPageId++;
    const bioPage: BioPage = {
      ...insertBioPage,
      id,
      description: insertBioPage.description || "",
      isActive: insertBioPage.isActive ?? true,
      customSettings: insertBioPage.customSettings as any,
      socialLinks: insertBioPage.socialLinks as any,
    };
    this.bioPages.set(id, bioPage);
    return bioPage;
  }

  async updateBioPage(id: number, updateBioPage: Partial<InsertBioPage>): Promise<BioPage | undefined> {
    const existingPage = this.bioPages.get(id);
    if (!existingPage) return undefined;

    const updatedPage: BioPage = {
      ...existingPage,
      ...updateBioPage,
      customSettings: updateBioPage.customSettings ? updateBioPage.customSettings as any : existingPage.customSettings,
      socialLinks: updateBioPage.socialLinks ? updateBioPage.socialLinks as any : existingPage.socialLinks,
    };
    this.bioPages.set(id, updatedPage);
    return updatedPage;
  }

  async deleteBioPage(id: number): Promise<boolean> {
    return this.bioPages.delete(id);
  }
}

export const storage = new MemStorage();