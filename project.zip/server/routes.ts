import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertBioPageSchema, designSettingsSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get user profile
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Create user
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Update user
  app.patch("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updateData = insertUserSchema.partial().parse(req.body);
      
      const updatedUser = await storage.updateUser(userId, updateData);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get bio page by page URL
  app.get("/api/bio/:pageUrl", async (req, res) => {
    try {
      const { pageUrl } = req.params;
      
      const user = await storage.getUserByPageUrl(pageUrl);
      if (!user || !user.isPublic) {
        return res.status(404).json({ message: "Bio page not found" });
      }

      const bioPage = await storage.getBioPageByUserId(user.id);
      if (!bioPage || !bioPage.isActive) {
        return res.status(404).json({ message: "Bio page not found" });
      }

      // Increment view count
      await storage.updateUser(user.id, { 
        viewCount: (user.viewCount || 0) + 1 
      });

      res.json({
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          bio: user.bio,
          avatar: user.avatar,
          banner: user.banner,
          backgroundImage: user.backgroundImage,
          viewCount: (user.viewCount || 0) + 1,
        },
        bioPage,
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get user's bio page
  app.get("/api/users/:userId/bio-page", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const bioPage = await storage.getBioPageByUserId(userId);
      if (!bioPage) {
        return res.status(404).json({ message: "Bio page not found" });
      }

      res.json({ user, bioPage });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Create bio page
  app.post("/api/users/:userId/bio-page", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const bioPageData = insertBioPageSchema.parse({ ...req.body, userId });
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Deactivate existing bio page
      const existingPage = await storage.getBioPageByUserId(userId);
      if (existingPage) {
        await storage.updateBioPage(existingPage.id, { isActive: false });
      }

      const bioPage = await storage.createBioPage(bioPageData);
      res.status(201).json(bioPage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Update bio page
  app.patch("/api/bio-pages/:id", async (req, res) => {
    try {
      const bioPageId = parseInt(req.params.id);
      const updateData = insertBioPageSchema.partial().parse(req.body);
      
      const updatedPage = await storage.updateBioPage(bioPageId, updateData);
      if (!updatedPage) {
        return res.status(404).json({ message: "Bio page not found" });
      }
      
      res.json(updatedPage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Update design settings
  app.patch("/api/bio-pages/:id/design", async (req, res) => {
    try {
      const bioPageId = parseInt(req.params.id);
      const designSettings = designSettingsSchema.parse(req.body);
      
      const updatedPage = await storage.updateBioPage(bioPageId, {
        customSettings: designSettings,
      });
      
      if (!updatedPage) {
        return res.status(404).json({ message: "Bio page not found" });
      }
      
      res.json(updatedPage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Update user images (avatar, banner, background)
  app.patch("/api/users/:id/images", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { avatar, banner, backgroundImage } = req.body;
      
      const updateData: Partial<any> = {};
      if (avatar !== undefined) updateData.avatar = avatar;
      if (banner !== undefined) updateData.banner = banner;
      if (backgroundImage !== undefined) updateData.backgroundImage = backgroundImage;
      
      const updatedUser = await storage.updateUser(userId, updateData);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
