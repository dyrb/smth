# Personal Curator - Deployment Guide

## Деплой на Ubuntu 22.04 с доменом specia.lol

### Предварительные требования

1. **Сервер Ubuntu 22.04** с root доступом
2. **Домен specia.lol** настроенный на IP сервера
3. **Supabase проект** с настроенной базой данных
4. **Минимум 2GB RAM** и 20GB свободного места

### Автоматический деплой

```bash
# 1. Скачайте проект на сервер
git clone <your-repo-url> /tmp/personal-curator
cd /tmp/personal-curator

# 2. Запустите скрипт деплоя
chmod +x deploy.sh
./deploy.sh
```

### Ручной деплой (пошагово)

#### 1. Подготовка сервера

```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Установка PM2
sudo npm install -g pm2

# Установка Nginx
sudo apt install -y nginx

# Установка Certbot для SSL
sudo apt install -y certbot python3-certbot-nginx
```

#### 2. Настройка приложения

```bash
# Создание директории приложения
sudo mkdir -p /var/www/personal-curator
sudo chown -R $USER:$USER /var/www/personal-curator

# Копирование файлов
cp -r . /var/www/personal-curator/
cd /var/www/personal-curator

# Установка зависимостей
npm ci --only=production

# Сборка приложения
npm run build

# Создание директории для логов
mkdir -p logs
```

#### 3. Настройка переменных окружения

```bash
# Копирование файла окружения
cp .env.production .env

# Редактирование переменных (замените на ваши данные)
nano .env
```

Обновите следующие переменные:
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
DATABASE_URL=your_database_url_with_password
```

#### 4. Настройка Nginx

```bash
# Копирование конфигурации Nginx
sudo cp nginx.conf /etc/nginx/sites-available/specia.lol
sudo ln -sf /etc/nginx/sites-available/specia.lol /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Проверка конфигурации
sudo nginx -t
```

#### 5. Настройка SSL

```bash
# Получение SSL сертификата
sudo certbot --nginx -d specia.lol -d www.specia.lol
```

#### 6. Запуск приложения

```bash
# Запуск через PM2
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup

# Перезапуск Nginx
sudo systemctl restart nginx
```

#### 7. Настройка файрвола

```bash
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
sudo ufw --force enable
```

### Управление приложением

#### PM2 команды
```bash
# Статус приложения
pm2 status

# Просмотр логов
pm2 logs personal-curator

# Перезапуск
pm2 restart personal-curator

# Остановка
pm2 stop personal-curator

# Удаление из PM2
pm2 delete personal-curator
```

#### Nginx команды
```bash
# Статус Nginx
sudo systemctl status nginx

# Перезапуск Nginx
sudo systemctl restart nginx

# Проверка конфигурации
sudo nginx -t
```

#### SSL сертификат
```bash
# Обновление сертификата
sudo certbot renew

# Проверка статуса сертификата
sudo certbot certificates
```

### Мониторинг и логи

#### Логи приложения
```bash
# PM2 логи
pm2 logs personal-curator

# Файлы логов
tail -f /var/www/personal-curator/logs/combined.log
tail -f /var/www/personal-curator/logs/err.log
```

#### Логи Nginx
```bash
# Access логи
sudo tail -f /var/log/nginx/access.log

# Error логи
sudo tail -f /var/log/nginx/error.log
```

#### Системные ресурсы
```bash
# Использование памяти и CPU
pm2 monit

# Системная информация
htop
df -h
free -h
```

### Обновление приложения

```bash
cd /var/www/personal-curator

# Остановка приложения
pm2 stop personal-curator

# Обновление кода (если используется git)
git pull origin main

# Установка новых зависимостей
npm ci --only=production

# Пересборка
npm run build

# Запуск приложения
pm2 start personal-curator
```

### Резервное копирование

#### База данных
Supabase автоматически создает резервные копии, но вы можете создать дополнительные:

```bash
# Экспорт через pg_dump (если есть прямой доступ)
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d_%H%M%S).sql
```

#### Файлы приложения
```bash
# Создание архива
tar -czf personal-curator-backup-$(date +%Y%m%d).tar.gz /var/www/personal-curator
```

### Troubleshooting

#### Проблемы с запуском
1. Проверьте логи: `pm2 logs personal-curator`
2. Убедитесь, что порт 3000 свободен: `sudo netstat -tlnp | grep 3000`
3. Проверьте переменные окружения в `.env`

#### Проблемы с SSL
1. Проверьте статус сертификата: `sudo certbot certificates`
2. Обновите сертификат: `sudo certbot renew`
3. Проверьте конфигурацию Nginx: `sudo nginx -t`

#### Проблемы с базой данных
1. Проверьте подключение к Supabase
2. Убедитесь, что DATABASE_URL корректный
3. Проверьте статус миграций в Supabase Dashboard

### Безопасность

1. **Регулярно обновляйте систему**: `sudo apt update && sudo apt upgrade`
2. **Мониторьте логи на подозрительную активность**
3. **Используйте сильные пароли для всех сервисов**
4. **Настройте автоматическое обновление SSL сертификатов**
5. **Регулярно создавайте резервные копии**

### Контакты и поддержка

- **Домен**: https://specia.lol
- **Админ-панель**: https://specia.lol/admin
- **API**: https://specia.lol/api

Для получения поддержки обращайтесь к администратору проекта.