/*
  # Invite System Implementation

  1. New Tables
    - `invites` - Invite codes with expiration and usage tracking
    - Update users table to track who invited them

  2. Security
    - Enable RLS on invites table
    - Add policies for invite management
    - Update user policies for invite tracking

  3. Functions
    - Generate unique invite codes
    - Check invite validity
    - Track invite usage
*/

-- Add invited_by column to users table with explicit foreign key name
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'invited_by'
  ) THEN
    ALTER TABLE users ADD COLUMN invited_by uuid;
    ALTER TABLE users ADD CONSTRAINT users_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES users(id);
  END IF;
END $$;

-- Create invites table
CREATE TABLE IF NOT EXISTS invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  created_by uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  used_by uuid REFERENCES users(id),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '1 year'),
  is_used boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  used_at timestamptz
);

-- Enable RLS on invites table
ALTER TABLE invites ENABLE ROW LEVEL SECURITY;

-- Function to generate unique invite code
CREATE OR REPLACE FUNCTION generate_invite_code()
RETURNS text AS $$
DECLARE
  chars text := 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  result text := '';
  i integer;
  code_exists boolean;
BEGIN
  LOOP
    result := '';
    FOR i IN 1..8 LOOP
      result := result || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
    END LOOP;
    
    SELECT EXISTS(SELECT 1 FROM invites WHERE code = result) INTO code_exists;
    
    IF NOT code_exists THEN
      EXIT;
    END IF;
  END LOOP;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Function to check if invite is valid
CREATE OR REPLACE FUNCTION is_invite_valid(invite_code text)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM invites 
    WHERE code = invite_code 
    AND NOT is_used 
    AND expires_at > now()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to use invite code
CREATE OR REPLACE FUNCTION use_invite_code(invite_code text, user_id uuid)
RETURNS boolean AS $$
DECLARE
  invite_record RECORD;
BEGIN
  SELECT * INTO invite_record FROM invites 
  WHERE code = invite_code 
  AND NOT is_used 
  AND expires_at > now();
  
  IF invite_record.id IS NULL THEN
    RETURN false;
  END IF;
  
  UPDATE invites 
  SET is_used = true, used_by = user_id, used_at = now()
  WHERE id = invite_record.id;
  
  UPDATE users 
  SET invited_by = invite_record.created_by
  WHERE id = user_id;
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create invite wave (give invites to all users)
CREATE OR REPLACE FUNCTION create_invite_wave()
RETURNS integer AS $$
DECLARE
  user_record RECORD;
  invite_count integer := 0;
BEGIN
  FOR user_record IN SELECT id FROM users WHERE NOT is_user_banned(id)
  LOOP
    INSERT INTO invites (code, created_by)
    VALUES (generate_invite_code(), user_record.id);
    invite_count := invite_count + 1;
  END LOOP;
  
  RETURN invite_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to purge user invites
CREATE OR REPLACE FUNCTION purge_user_invites(target_user_id uuid)
RETURNS integer AS $$
DECLARE
  deleted_count integer;
BEGIN
  DELETE FROM invites 
  WHERE created_by = target_user_id 
  AND NOT is_used;
  
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RLS Policies for invites
CREATE POLICY "Users can read their own invites"
  ON invites
  FOR SELECT
  TO authenticated
  USING (created_by = auth.uid() OR used_by = auth.uid());

CREATE POLICY "Users can create their own invites"
  ON invites
  FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid());

CREATE POLICY "Admins can manage all invites"
  ON invites
  FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "Public can read valid invites for registration"
  ON invites
  FOR SELECT
  TO anon
  USING (NOT is_used AND expires_at > now());

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_invites_code ON invites(code);
CREATE INDEX IF NOT EXISTS idx_invites_created_by ON invites(created_by);
CREATE INDEX IF NOT EXISTS idx_invites_used_by ON invites(used_by);
CREATE INDEX IF NOT EXISTS idx_invites_expires_at ON invites(expires_at);
CREATE INDEX IF NOT EXISTS idx_invites_is_used ON invites(is_used);
CREATE INDEX IF NOT EXISTS idx_users_invited_by ON users(invited_by);